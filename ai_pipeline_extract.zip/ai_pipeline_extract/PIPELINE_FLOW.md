# Pipeline flow — every LLM call, in order

Notation: `prompt` → **model** → output. Every call is wrapped in
`log_llm_call(provider, model, api, operation)` (`llm_calls/llm_call_logging.py`), so the
`operation` label is how you find a given call in the terminal log.

---

## Flow 1 — Step 1: text prompt → 2D floor plan

**Entry:** `entrypoints/ai_service.py :: generate_2d_from_prompt` → `llm_calls/architect.py :: ArchitectService.generate_2d_plan`

1. Prompt = `prompts.ARCHITECT_2D_PROMPT_TEMPLATE.format(description=<user prompt>)`
   (`prompts/prompts_guided_render.py`, line ~128).
2. `contents = [prompt]`; if a reference image was uploaded, `types.Part.from_bytes(...)` is appended.
3. Engine chain, tried in order until one returns an inline image:
   - Vertex AI `gemini-3-pro-image-preview`
   - Google AI Studio `gemini-3-pro-image-preview`
   - Google AI Studio `gemini-2.5-flash`
   Each call: `client.models.generate_content(model, contents, config=GenerateContentConfig(response_modalities=['TEXT','IMAGE']))`.
4. Falling through an engine appends a warning (`"Current model X is exhausted…"`); the last
   failure raises a user-mapped error.
5. Image saved as `/outputs/plan_2d_<uuid>.png`.

`refine_2d` reuses the same call, prefixing the prompt with the existing room summaries.
`generate_2d_from_upload` makes **no** LLM call — the upload is used as-is.

---

## Flow 2 — Trace / analyze the plan into machine instructions

Two different analyzers exist, feeding two different pipelines. Both matter.

### 2a. Vectorizer → FloorPlan JSON (official Step 2)

**Entry:** `POST /step2/analyze-floorplan` → `guided_rendering.analyze_floorplan_verified_sync`
→ `llm_calls/floorplan_analyzer.py :: analyze_floorplan_verified`

1. `support/image_preparation_service.py :: prepare_image` — PDF→PNG, downscale to
   `MAX_IMAGE_DIM`, produce a `data:image/png;base64` URL.
2. Messages = `build_messages(SYSTEM_PROMPT, USER_PROMPT, plan_data_url)` — system prompt is
   the long floor-plan vectorizer spec (units, scale, watertight corners, hard validation
   limits, exact JSON schema) in `prompts/prompts_guided_render.py`.
3. **Model:** `openai/gpt-5.6-sol` via `openrouter_floorplan_client.complete()`
   (`json_object`, `temperature=0.1`, `max_tokens=16000`). Operation label: `floorplan-extract`.
4. **Self-heal loop** (`MAX_ATTEMPTS = 3`): on JSON/schema failure the raw output + the exact
   error are fed back through `REPAIR_PROMPT_TEMPLATE`; retries are logged as
   `floorplan-extract (schema-retry N)`. Truncated output (`finish_reason == "length"`) is
   flagged separately and the bad output is **not** echoed back.
5. Result validated against `support/floorplan_schema.py :: FloorPlan`.

**Gate 1 (fidelity audit)** — `llm_calls/verification.py :: audit_floorplan`:
- Deterministic `structural_sanity()` checks first (free, no AI).
- `support/floorplan_snapshot_renderer.py` renders a grey massing snapshot from the JSON.
- Judge call: `_JUDGE_SYSTEM` + `_AUDIT_USER` with `[plan_png, snapshot_png]`, operation
  `fidelity-audit (gate1)`. The audit contract explicitly tells the judge the massing shell
  has no doors/windows so it can't fail on that.
- On fail: `repair_floorplan_against_plan` (`_REPAIR_AGAINST_PLAN`, operation
  `floorplan-repair (gate1)`), up to `FIDELITY_MAX_EXTRACTION_ATTEMPTS` (default 2).
  Best-scoring plan wins. **Fails open** — a judge error returns the plain extraction.

The resulting JSON is persisted on the layout asset and later distilled into the
`EXACT GEOMETRY FACTS` block (`prompts/prompts_floorplan_extract_repair.py`).

### 2b. Space-type analyzer → furniture / dimension instructions (rendering.py pipeline)

**Entry:** `llm_calls/rendering.py :: RenderingService._analyze_floorplan_type`

1. Prompt = `Prompts.STAGE_2A_ANALYZE_FLOORPLAN` + the floor-plan image.
2. Text-only call (`text_only=True`) → `google/gemini-3-pro-image-preview`, `max_tokens=3000`.
   Operation: `text analysis`. Returns JSON: space type, key rooms, `furniture_coverage`,
   `dimension_coverage`, per-room furniture, unit system, wall/door/window estimates.
3. Robust JSON extraction (`_extract_json_object`, with regex salvage). Any failure returns
   the hard-coded `defaults` dict — generation never stops.
4. That analysis becomes prompt text via `_build_furniture_mandate` (zero / mirroring /
   partial room table) and `_build_measurement_mandate` (three-tier dimension system) — both
   in `prompts/prompts_rendering_dynamic_builders.py`.

---

## Flow 3 — 2D → 3D, official Step 2 (guided render)

**Entry:** `services.py` → `llm_calls/guided_rendering.py :: generate_guided_render_checked`

Requires a `snapshot_asset_id`: the **frontend Three.js WebGL snapshot**, built in the browser
from the FloorPlan JSON of Flow 2a.

1. `_normalize_mode(mode, style)` → `"sketchup"` (default) or `"photoreal"`.
2. Images assembled **in this exact order** (the prompt describes it literally):
   1. snapshot (IMAGE 1 — sole authority for geometry *and* camera)
   2. original 2D CAD plan, normalized to PNG (IMAGE 2 — cross-check only)
   3. bundled SketchUp style ref, *if the file exists* (it currently does not)
   4. user style references, in caller order
3. Prompt = `build_render_prompt(mode, rooms, style, description, has_refs, geometry_facts)`
   = `INPUTS_PREAMBLE` + `_PLAN_BLOCK` + (`PHOTOREAL_PROMPT_TEMPLATE` | `SKETCHUP_PROMPT_TEMPLATE`)
   + `_DIMENSION_LABEL_BLOCK` + `_CAMERA_DIRECTIVE` + `REFERENCE_CLAUSE` (only if refs).
   `geometry_facts` (room/door/window counts + footprint from the extracted JSON) is
   interpolated into `_PLAN_BLOCK`.
4. **Model:** `google/gemini-3-pro-image-preview` via OpenRouter `chat/completions`,
   `modalities:["image","text"]`, no temperature/seed. Operation: `guided image generation`.
   On any failure and if `GEMINI_API_KEY` is set → Google GenerativeLanguage
   `:generateContent` with `responseModalities:["TEXT","IMAGE"]`.
5. **Lean render check** (`RENDER_VERIFY_ENABLED`, default on):
   - One judge call — `_JUDGE_SYSTEM` + `_VERIFY_USER` with `[plan_png, render_png]` on
     **`anthropic/claude-haiku-4.5`**, operation `render-verify`.
   - Pass (`score >= RENDER_VERIFY_MIN_SCORE=75` and `layout_matches`) → done.
   - Fail → **exactly one** retry, with the judge's discrepancies appended as a
     `[FIDELITY CORRECTIONS - HIGHEST PRIORITY]` block (the design prompt above is untouched).
     Then the higher-scoring of the two attempts wins.
   - This is deliberately **not** the removed best-of-N gate. Do not grow it back into a loop.

---

## Flow 4 — 2D → 3D, two-stage rendering pipeline (`rendering.py`)

**Entry:** `ai_service.generate_3d` → `RenderingService.generate_initial_render`

**Stage 1 — geometry anchor** (`generate_base_3d`)
- Prompt = `Prompts.STAGE_1_GEOMETRY` + the floor-plan image (loaded through
  `CanvasProcessor.prepare_input`).
- Image call via `_generate_with_fallback` → OpenRouter `google/gemini-3-pro-image-preview`
  (`temperature=0.0, top_p=0.0, seed=42, modalities=["image","text"]`), Vertex Gemini fallback
  only on the error markers listed in `_should_fallback_to_vertex`.
- Output cached under `generated_outputs/stage1_cache/<cache_key>.png`.

**Stage 2A — analysis:** see Flow 2b.

**Stage 2B — universal style compositor** (`apply_universal_style`)
- Prompt = `Prompts.STAGE_2B_APPLY_STYLE_NO_REF.format(...)` with:
  `space_type`, `subtype_notes`, `style_recommendation`, `furniture_mandate`,
  `lighting_environment=Prompts.LIGHTING_ENVIRONMENT`, `measurement_mandate`,
  `style_descriptor=Prompts.STYLE_PRESETS["modern_residential"]`,
  `user_instruction_block=_build_initial_user_instruction_block(initial_user_prompt)`.
  The template already ends with `_ANTI_SHADOW_BLOB_FINAL_CHECK`.
- `contents = [style_prompt, "IMAGE 1 — LAYOUT REFERENCE ONLY…", base_img, final_reminder]`
  — the 11-point `final_reminder` is last for recency (`prompts/prompts_inline_fragments.txt`).
- Reference images are accepted by the signature but **intentionally ignored**; the pipeline
  is single-universal-style by design and appends a warning when refs are passed.
- Output padded by `CanvasProcessor.add_safe_canvas` before saving.

---

## Flow 5 — Direct-instruction edit of a generated image (chat edit)

**Entry:** `services.py` → `ai_service.edit_3d_chat` → `RenderingService.edit_by_instruction`

1. `_select_edit_source_path` picks the base image: selected 3D → latest 3D → session memory.
   **Hard rule: the original 2D floor plan can never be the edit source.**
2. Prompt = `Prompts.STAGE_CHAT_EDIT_WITH_HISTORY.format(edit_history, instruction, strict_edit_scope_lock)`
   where `edit_history` = `EditSessionMemory.history_summary()` (last 8 edits, persisted to
   `generated_outputs/sessions/session_<md5>.json`) and `strict_edit_scope_lock` =
   `Prompts._STRICT_EDIT_SCOPE_LOCK.format(instruction=…)`.
3. Appended in order: `LIGHTING_ENVIRONMENT`, `_ANTI_SHADOW_BLOB_FINAL_CHECK`.
4. `contents = [edit_prompt, "IMAGE 1 — CURRENT/LATEST 3D RENDER ONLY…", current_img, "★ FINAL STRICT EDIT REMINDER…"]`.
5. Image call via `_generate_with_fallback`. Result recorded into session memory under both
   the resolved key and the raw key (back-compat).

---

## Flow 6 — Area edit (traced region)

**Entry:** `[AREA_EDIT]` prefixed prompt + edited image → `ai_service.edit_3d_area` → `RenderingService.edit_area`

1. Same edit-source rule as Flow 5.
2. `_build_area_edit_region_guide(current_img, annotated_img)` — **not an LLM call**: pixel
   diff → connected-component filtering → dilation/blur → cyan `(0,220,255)` overlay.
3. Prompt = `Prompts.STAGE_EDIT_AREA.format(instruction, strict_edit_scope_lock)`
   + `LIGHTING_ENVIRONMENT` + `_ANTI_SHADOW_BLOB_FINAL_CHECK`.
4. `contents = [edit_prompt, "IMAGE 1 — CLEAN CURRENT 3D RENDER ONLY…", current_img,
   "IMAGE 2 — EDIT-ZONE GUIDE…", region_guide, "★ FINAL STRICT AREA-EDIT REMINDER…"]`.
5. Outside the cyan region the model is told to produce a pixel-perfect copy.

---

## Flow 7 — Isometric / bird's-eye and other camera angles

**Entry:** `services.py :: _execute_isometric` → `RenderingService.generate_angled_view`

- `isometric` and `birds_eye` are aliases: both route to `generate_isometric_from_image`, which
  **ignores any caller-supplied prompt** and always uses the server-side
  `_ISOMETRIC_CAMERA_PROMPT` (camera-only edit, absolute preservation, strict non-invention).
- `contents = ["SOURCE 3D IMAGE — immutable scene reference; change only its camera:", source_img, final_prompt]`.
- **Model chain:** `openai/gpt-5.4-image-2` (`OPENROUTER_MODEL_ISOMETRIC`) → default OpenRouter
  render model → Vertex Gemini. This is the only image call that prefers a non-default model;
  `_generate_with_fallback(openrouter_model=…)` handles the chain.
- `_response_matches_source()` md5-compares output to input and warns if the model returned the
  image unchanged.
- `front_elevation` / `side_elevation` / `corner_perspective` use `_ANGLE_PROMPTS` + a 5-point
  final reminder on the default model.

---

## Flow 8 — Refine the 3D geometry from the render (Improve 3D)

**Entry:** `POST /step2/refine` → `llm_calls/floorplan_analyzer.py :: refine_floorplan`

- Images: `[snapshot, cad_plan, render]` (or `[snapshot, render]` when no CAD is available) —
  the legend text switches with `REFINE_LEGEND_WITH_CAD` / `REFINE_LEGEND_NO_CAD`.
- User text = `REFINE_USER_PROMPT_TEMPLATE.format(image_legend, current_json[:8000])`,
  system prompt stays `SYSTEM_PROMPT` (same schema + accuracy rules).
- Same self-healing validation loop, operation `floorplan-refine`.

---

## Flow 9 — Single-room render

`RenderingService.generate_room` — one inline f-string prompt (room type + style + clean-floor
constraints), no reference images, default image model. See `prompts_inline_fragments.txt`.

---

## Not part of image generation

`boq_llm_calls/` — BOQ agent (`anthropic/claude-fable-5`, strands `Agent` with a 4-step
approval-gated workflow), requirements analysis agent, materials extraction (OpenRouter and
OpenAI `gpt-4o-mini` variants), pricing web search + Pinecone vector search embeddings.
Listed for completeness only.
