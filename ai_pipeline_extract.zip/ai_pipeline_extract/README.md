# AI Image-Generation Pipeline — Clean Extract

Everything in this folder is **prompts** and **LLM calls** taken out of `backend/app/`,
**word-for-word and byte-for-byte**. Nothing was rewritten, rephrased, re-indented or
"improved". Model IDs, sampling parameters, message structures, image ordering, retry
logic and fallback chains are exactly what production runs today.

> Guarantee: every whole file here is `filecmp`-identical to its source, and every
> partial file is an exact line-slice of its source (each block carries a
> `VERBATIM SLICE — <source file> lines A-B` banner). This was verified after the
> copy: 20/20 files identical, 23/23 slices identical, all Python files compile.

Only these lines were **added**, always clearly marked: the header comment, the `import`
lines, one `class ...:` wrapper where a slice was a class/method body that cannot stand
alone, and the **LIVE / DEAD banners** described below.

---

## ⚠️ Read this first: most of `rendering.py`'s prompts are dead

A reachability audit found that roughly **1430 of the ~1845 lines of prompt text in
`rendering.py` are unreachable** from any route or job in the app. The whole two-stage
pipeline (Stage 1 geometry → Stage 2A analysis → Stage 2B style compositor) has not run
since **2026-06-12**; everything since then has gone through the guided pipeline.

Proof, from `backend/generated_outputs/renders/`:
`guided_render_*` 209 files (newest 2026-07-28) · `ISOMETRIC_*` 24 · `CHAT_EDIT_*` 13 ·
`AREA_EDIT_*` 6 · `STAGE2_*` 4 (newest 2026-06-12) · `ROOM_*` 0 (never ran).

**Every prompt in `prompts/` is wrapped in a banner at its start and end:**

```
# ╔═══ DEAD ═════════════════════════════════════════════════════════╗
# ║ STAGE_1_GEOMETRY — Stage 1 white-box geometry anchor
# ║ source: backend/app/ai/rendering.py  lines 386-621
# ║ Reason: only reachable through RenderingService.generate_initial_render,
# ║         ... No route ever creates JobType.GEN_3D_AND_BOQ -> unreachable.
# ╚══════════════════════════════════════════════════════════════════╝
        <the prompt, byte-identical>
# ╚═══ END DEAD: STAGE_1_GEOMETRY ═══════════════════════════════════╝
```

- **LIVE** — running in production today
- **DEAD** — defined but unreachable from any route/job
- **UI-UNREACHABLE** — hittable by POSTing the API directly, but no UI path reaches it

Nothing was deleted. `grep -c "╔═══ DEAD" prompts/*` gives you the count per file, and
`PROMPT_INDEX.md` has the full per-prompt table. **If you're rebuilding the pipeline, you
only need the LIVE ones** — the DEAD blocks are kept so you can revive the two-stage path
later if you ever want it.

The pristine, un-annotated originals are in `llm_calls/` (still byte-identical).

---

## Folder map

| Folder | What's in it |
|---|---|
| `config/` | `config.py` — API keys, **all model IDs**, timeouts, fidelity-gate knobs. Read this first. |
| `prompts/` | Prompt-only views. Every prompt string in the pipeline, nothing else. |
| `llm_calls/` | The actual call sites — request building, parameters, response parsing, fallbacks. Original filenames kept. |
| `support/` | Non-LLM modules the calls import and cannot run without (image prep, FloorPlan schema, style-ref reader, massing snapshot renderer). |
| `entrypoints/` | `ai_service.py` — thin dispatch layer, no LLM call of its own. Included only to show how each flow is entered. |
| `boq_llm_calls/` | BOQ / cost-estimation agents. **Not part of the image pipeline** — included only so the "every LLM call" inventory is complete. Delete it if you're rebuilding image generation alone. |

Read `PIPELINE_FLOW.md` for the end-to-end flow of each of the 8 requested flows, and
`PROMPT_INDEX.md` for a one-line-per-prompt index with source references.

---

## prompts/

| File | Contents | Source |
|---|---|---|
| `prompts_guided_render.py` | **Current Step-2 pipeline.** Floor-plan vectorizer system prompt, schema-repair prompt, 2D architect prompt, `INPUTS_PREAMBLE`, photoreal + sketchup render templates, dimension-label block, camera directive, refine prompts, `build_render_prompt()` | full copy of `app/ai/prompts.py` |
| `prompts_rendering_stage.py` | `StyleSpec` (locked colour/material table) + the whole `Prompts` class: Stage 1 geometry, Stage 2A analyzer, Stage 2B compositors, lighting, furniture mandates, edit-scope lock, area/chat edit templates + isometric & angle-view prompts | slices of `app/ai/rendering.py` |
| `prompts_rendering_dynamic_builders.py` | The 4 runtime prompt builders: edit-scope lock, furniture mandate, three-tier measurement mandate, initial-user-prompt router | slices of `app/ai/rendering.py` |
| `prompts_verification_qa.py` | Judge system prompt, JSON contracts, Gate-1 audit prompt, render-verify prompt | slice of `app/ai/verification.py` |
| `prompts_floorplan_extract_repair.py` | Gate-1 repair instruction + the `EXACT GEOMETRY FACTS` block appended to the render prompt | slices of `floorplan_analyzer.py`, `guided_rendering.py` |
| `prompts_inline_fragments.txt` | Prompt strings written inline inside call bodies (Stage 2B final reminder, chat-edit reminder, area-edit reminder, room prompt, fidelity-correction appendix). `.txt` because their indentation cannot stand alone as Python. | slices of `rendering.py`, `guided_rendering.py` |
| `prompts_boq_and_estimation.txt` | BOQ agent + estimation prompts (not image pipeline) | slices of `boq/*`, `estimation.py` |

## llm_calls/

| File | The call it makes |
|---|---|
| `architect.py` | **Step 1: prompt → 2D plan.** 3-engine fallback (Vertex 3 Pro → Gemini 3 Pro → Gemini 2.5 Flash), `generate_content` with `response_modalities=['TEXT','IMAGE']` |
| `openrouter_floorplan_client.py` | Generic OpenRouter `chat/completions` for JSON: `response_format=json_object`, `temperature=0.1`, `max_tokens=16000`, truncation detection |
| `floorplan_analyzer.py` | **Trace/analyze 2D → FloorPlan JSON + description.** Self-healing schema loop (`MAX_ATTEMPTS=3`), Gate-1 verified variant, repair-against-plan, refine |
| `verification.py` | Gate-1 audit judge + lean render-verify judge (fast model), both fail-open |
| `gemini_image_service.py` | **The guided 3D image call.** OpenRouter `modalities:["image","text"]`, falls back to Google GenerativeLanguage `:generateContent` |
| `guided_rendering.py` | **Current Step 2 orchestrator.** Assembles image order + prompt, 1 generation → 1 judge → at most 1 corrective retry |
| `rendering.py` | The full 2-stage `RenderingService`: Stage 1 geometry, Stage 2A analysis, Stage 2B style, chat edit, area edit, isometric, angle views, room render, OpenRouter↔Vertex fallback, response/image extraction |
| `llm_call_logging.py` | `log_llm_call()` context manager wrapping every outbound call |

---

## Model IDs actually in use (from `config/config.py`)

| Purpose | Model |
|---|---|
| Guided Step-2 render (image) | `google/gemini-3-pro-image-preview` (OpenRouter) |
| Rendering-service image gen | `google/gemini-3-pro-image-preview` (OpenRouter) |
| Rendering-service text analysis | `google/gemini-3-pro-image-preview`, `max_tokens=3000` |
| Floor-plan JSON extraction | `openai/gpt-5.6-sol` (OpenRouter) |
| Isometric / bird's-eye re-render | `openai/gpt-5.4-image-2` (OpenRouter) |
| Render fidelity judge | `anthropic/claude-haiku-4.5` (OpenRouter) |
| Google fallback (guided) | `gemini-3-pro-image-preview` via `GEMINI_IMAGE_MODEL` |
| Vertex fallback | `gemini-3-pro-image-preview` |
| Step-1 2D architect | `gemini-3-pro-image-preview` → `gemini-2.5-flash` |
| BOQ agent (not image) | `anthropic/claude-fable-5` |
| Estimation (not image) | `gpt-4o-mini` (OpenAI direct) |

### Sampling parameters — these matter for reproducing results

- **OpenRouter image gen** (`rendering.py`): `temperature=0.0, top_p=0.0, seed=42, modalities=["image","text"]`; if the model rejects those params with a 400, they are dropped and the call is retried once.
- **Vertex image**: `temperature=0.05, top_k=1, top_p=0.0, seed=42, response_modalities=["IMAGE","TEXT"]`.
- **Vertex text**: `temperature=0.0, top_k=1, top_p=0.0, seed=42`.
- **Floor-plan extraction**: `response_format={"type":"json_object"}, temperature=0.1, max_tokens=16000`.
- **Guided render** (`gemini_image_service.py`): **no** temperature/seed — only `modalities:["image","text"]`.

---

## Things to know before you rebuild

1. **Image order is part of the prompt.** For the guided render the model receives, in this
   exact order: text prompt → WebGL snapshot (IMAGE 1, the geometry + camera authority) →
   original 2D CAD plan (IMAGE 2, cross-check only) → bundled style ref → user style refs.
   `INPUTS_PREAMBLE` in `prompts_guided_render.py` describes that order literally — changing
   the order silently breaks the prompt.
2. **`SKETCHUP_STYLE_REF` does not exist on disk.** `config.py` points at
   `app/ai/assets/sketchup_style.png`; that folder only contains a `README.md`. So
   `bundled_sketchup_reference()` returns `None` and `has_refs` stays `False` unless the user
   attaches references. Current behaviour, preserved — don't "fix" it without testing.
3. **Both 3D pipelines are live.** The official Step 2 path is `guided_rendering.py` (needs a
   frontend Three.js WebGL snapshot). `rendering.py`'s two-stage path is what serves chat
   edits, area edits, isometric views and room renders. Neither is dead code.
4. **Every QA gate fails open.** A judge error never blocks generation. Keep that or you'll
   turn transient verifier failures into user-facing errors.
5. **`config.py` line 111 contains a hard-coded API key** (`GROQ_API_KEY = "xai-..."`). It is
   copied verbatim because you asked for verbatim, but it is unused by the pipeline — nothing
   reads it except the standalone test file. Rotate that key and drop the line.

## Deliberately excluded

| File | Why |
|---|---|
| `app/ai/test.py` | Standalone Groq/xAI validation script. Not imported anywhere in the pipeline. |
| `app/ai/dimension_overlay.py` | Deterministic pixel overlay, no LLM. Currently disabled — Gemini draws the dimension labels itself. |
| `app/routes.py`, `app/services.py` | HTTP + job orchestration. No prompts, no LLM calls. |
| `app/storage.py`, `models.py`, `schemas.py`, `db.py`, `premium_*`, `cad_export.py` | Generic backend, unrelated. |
