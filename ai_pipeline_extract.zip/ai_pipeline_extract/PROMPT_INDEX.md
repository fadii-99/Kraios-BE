# Prompt index — with LIVE / DEAD status

Status was determined by tracing every caller back to a route, and confirmed against
the actual output files on disk. Every prompt in `prompts/` carries the same status as a
banner at its **start and end**, so you can also see it in the code itself.

- **LIVE** — reachable and running in production today
- **DEAD** — defined but unreachable from any route/job
- **UI-UNREACHABLE** — reachable by POSTing to the API directly, but no UI path reaches it

Line numbers refer to `backend/app/`; the pristine copies in `llm_calls/` are byte-identical,
so the same numbers apply there.

## Why the two-stage pipeline is dead

`_execute_gen_3d` (the only handler for `JobType.GEN_3D`) has exactly three branches:
area edit, chat edit, and the guided render — and the guided branch **raises** if there is no
`snapshot_asset_id`. The two-stage path (`generate_initial_render` → Stage 1 → Stage 2A →
Stage 2B) is only reachable through `ai_service.generate_3d` / `edit_render`, which are only
called by `_execute_gen_3d_and_boq` and `_execute_room_render`. **No route ever creates
`JobType.GEN_3D_AND_BOQ` or `JobType.ROOM_RENDER`.** `JobType.REFINE_2D` isn't even dispatched.

Confirmed on disk in `backend/generated_outputs/renders/`:

| prefix | files | newest |
|---|---|---|
| `guided_render_*` | 209 | 2026-07-28 |
| `ISOMETRIC_*` | 24 | 2026-07-25 |
| `CHAT_EDIT_*` | 13 | 2026-07-18 |
| `AREA_EDIT_*` | 6 | 2026-06-25 |
| `STAGE2_*` | 4 | 2026-06-12 |
| `ROOM_*` | 0 | never |

---

## `ai/prompts.py` → `prompts/prompts_guided_render.py`
Essentially the whole live pipeline.

| Status | Constant | Lines | Used by |
|---|---|---|---|
| LIVE | `SYSTEM_PROMPT` | 4–110 | floor-plan vectorizer — every `floorplan_analyzer` call |
| LIVE | `USER_PROMPT` | 112–115 | `analyze_floorplan` |
| LIVE | `REPAIR_PROMPT_TEMPLATE` | 117–126 | schema self-heal loop |
| LIVE | `ARCHITECT_2D_PROMPT_TEMPLATE` | 128–156 | **Step 1** 2D generation |
| LIVE | `INPUTS_PREAMBLE` | 164–187 | head of both render templates |
| LIVE | `_CAMERA_DIRECTIVE` | 190–195 | tail of both render templates |
| LIVE | `REFERENCE_CLAUSE` | 198–202 | only when style refs attached |
| LIVE | `_PLAN_BLOCK` | 204–212 | `{plan_description}` `{rooms}` `{geometry_facts}` |
| LIVE | `_DIMENSION_LABEL_BLOCK` | 217–234 | dimension callouts |
| LIVE | `PHOTOREAL_PROMPT_TEMPLATE` | 236–281 | mode `photoreal` (Step2.jsx offers it) |
| LIVE | `SKETCHUP_PROMPT_TEMPLATE` | 284–330 | default mode |
| **DEAD** | `DEFAULT_STYLE` | 332 | zero references |
| LIVE | `RENDER_MODES` | 335–342 | mode → (template, style) |
| LIVE | `REFINE_USER_PROMPT_TEMPLATE` | 347–363 | `/step2/refine` (client.js:320) |
| LIVE | `REFINE_LEGEND_WITH_CAD` / `_NO_CAD` | 366–373 / 374–379 | refine image legend |
| LIVE | `build_render_prompt()` | 382–405 | assembles the guided render prompt |

## `ai/rendering.py` → `prompts/prompts_rendering_stage.py`
Mostly dead. ~1430 lines unreachable vs ~415 live.

| Status | Constant | Lines | Note |
|---|---|---|---|
| **DEAD** | `StyleSpec` + `to_prompt_table()` | 92–186 | only feeds the dead `STAGE_2B_APPLY_STYLE` |
| **DEAD** | `STAGE_1_GEOMETRY` | 386–621 | 236 lines; Stage 1 unreachable |
| **DEAD** | `STAGE_2A_ANALYZE_FLOORPLAN` | 627–688 | image→instructions, only for Stage 2B |
| **DEAD** | `STAGE_2A_EXTRACT_STYLE` | 694–741 | prompt itself says "DISABLED LEGACY" |
| **DEAD** | `_GEOMETRY_LOCK_HEADER` | 747–774 | only heads the two dead 2B templates |
| LIVE | `_ANTI_SHADOW_BLOB_FINAL_CHECK` | 782–811 | appended to both edits |
| LIVE | `_STRICT_EDIT_SCOPE_LOCK` | 813–878 | injected into both edits |
| **DEAD** | `_ZERO_FURNITURE_MANDATE` | 885–929 | via `_build_furniture_mandate` → dead |
| **DEAD** | `_FURNITURE_MIRRORING_MANDATE` | 932–953 | same |
| **DEAD** | `_PARTIAL_FURNITURE_MANDATE` | 955–975 | same |
| LIVE | `LIGHTING_ENVIRONMENT` | 981–1049 | appended to both edits |
| **DEAD** | `STAGE_2B_APPLY_STYLE` | 1057–1307 | **zero references** — 251 lines never run |
| **DEAD** | `STAGE_2B_APPLY_STYLE_NO_REF` | 1313–1411 | Stage 2B unreachable |
| **DEAD** | `RESIDENTIAL_SKETCHUP_STYLE` / `STYLE_PRESETS` | 1417–1445 / 1447–1450 | only `{style_descriptor}` of dead 2B |
| LIVE | `STAGE_EDIT_AREA` | 1456–1496 | **area edit** |
| LIVE | `STAGE_CHAT_EDIT_WITH_HISTORY` | 1502–1536 | **chat edit** |
| **DEAD** | `STAGE_CHAT_EDIT` | 1538–1555 | zero references |
| **DEAD** | `REFERENCE_CATEGORY_MAP` | 1557–1570 | zero references |
| LIVE | `_ISOMETRIC_CAMERA_PROMPT` | 3615–3757 | serves both UI angle options |
| **UI-UNREACHABLE** | `_ANGLE_PROMPTS` | 3883–3929 | front/side/corner not in `VIEW_ANGLES` |

## `ai/rendering.py` builders → `prompts/prompts_rendering_dynamic_builders.py`

| Status | Builder | Lines | Note |
|---|---|---|---|
| LIVE | `_strict_edit_scope_lock()` | 1858–1860 | both edits |
| **DEAD** | `_build_furniture_mandate()` | 2567–2602 | only `apply_universal_style` |
| **DEAD** | `_build_measurement_mandate()` | 2604–2879 | 276 lines; live path uses `_DIMENSION_LABEL_BLOCK` instead |
| **DEAD** | `_build_initial_user_instruction_block()` | 2886–2971 | only `apply_universal_style` |

## Inline fragments → `prompts/prompts_inline_fragments.txt`

| Status | Fragment | Lines |
|---|---|---|
| **DEAD** | Stage 2B `final_reminder` + `contents[]` | `rendering.py` 3054–3073 |
| LIVE | chat-edit `contents[]` + reminder | `rendering.py` 3393–3406 |
| LIVE | area-edit `contents[]` + reminder | `rendering.py` 3522–3538 |
| **DEAD** | room render prompt | `rendering.py` 4042–4049 |
| LIVE | `[FIDELITY CORRECTIONS]` retry appendix | `guided_rendering.py` 189–199 |

## QA judges → `prompts/prompts_verification_qa.py` — all LIVE

`_JUDGE_SYSTEM` 36–41 · `_JUDGE_JSON_CONTRACT` 43–61 · `_AUDIT_JSON_CONTRACT` 66–87 ·
`_AUDIT_USER` 89–97 · `_VERIFY_USER` 99–107

## Repair / geometry facts → `prompts/prompts_floorplan_extract_repair.py` — all LIVE

`_REPAIR_AGAINST_PLAN` (`floorplan_analyzer.py` 136–146) · `_geometry_facts()`
(`guided_rendering.py` 97–143)

## BOQ / estimation → `prompts/prompts_boq_and_estimation.txt` — all LIVE, separate feature

BOQ main agent (`boq/main_agent.py` 41–190) · requirements agent (`boq/agents.py` 241–270) ·
materials extraction OpenRouter (`boq/agents.py` 141–161) · materials extraction OpenAI
(`estimation.py` 65–85) · pricing estimate (`estimation.py` 148–160) · web-results parsing
(`boq/search_agent.py` 244–266) · material-list parsing (`boq/search_agent.py` 407–419)
