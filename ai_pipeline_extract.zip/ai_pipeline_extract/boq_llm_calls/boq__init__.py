"""
BOQ Chat Module - Agent-based conversation system for Bill of Quantities.

This module provides an AI agent-based chat system for generating BOQ through
natural conversation. The agent can:
- Analyze PDF documents
- Extract requirements
- Search pricing information
- Generate formatted BOQ tables

Usage:
    from app.ai.boq import run_boq_agent
    response = run_boq_agent(message, session_id, project_context)
"""

from app.ai.boq.main_agent import run_main_agent, stream_main_agent
from typing import Optional

def run_boq_agent(message: str, session_id: str, project_context: Optional[str] = None, images=None) -> str:
    """
    Run the BOQ agent with a message and session ID.

    Args:
        message: User message
        session_id: Session ID for conversation context
        project_context: Optional finalized project context from prior workflow steps
        images: Optional list of (bytes, format) tuples fed to the vision model
            (e.g. the approved 3D render)

    Returns:
        Agent response as string
    """
    return run_main_agent(message, session_id, project_context=project_context, images=images)

async def stream_boq_agent(message: str, session_id: str, project_context: Optional[str] = None, images=None):
    """
    Stream the BOQ agent response with a message and session ID.

    Args:
        message: User message
        session_id: Session ID for conversation context
        project_context: Optional finalized project context from prior workflow steps
        images: Optional list of (bytes, format) tuples fed to the vision model
            (e.g. the approved 3D render)

    Yields:
        Text chunks from the agent response
    """
    async for chunk in stream_main_agent(message, session_id, project_context=project_context, images=images):
        yield chunk

__all__ = ["run_boq_agent", "stream_boq_agent", "run_main_agent", "stream_main_agent"]
