# Floor-plan repair prompt + geometry-facts block. All LIVE.
#
# ANNOTATED VIEW — prompt text is byte-identical to the source; the only
# added lines are the LIVE / DEAD marker banners that wrap each prompt, plus
# this header and imports. Pristine un-annotated originals: ../llm_calls/
#
#   LIVE            = reachable and actually running in production today
#   DEAD            = defined but unreachable from any route/job in the app
#   UI-UNREACHABLE  = reachable via direct API call, but no UI path reaches it
#
# Source of truth: backend/app/ai/floorplan_analyzer.py, backend/app/ai/guided_rendering.py
from typing import Optional


# ╔═══ LIVE ════════════════════════════════════════════════════════════╗
# ║ _REPAIR_AGAINST_PLAN
# ║ source: backend/app/ai/floorplan_analyzer.py  lines 134-146
# ║ Gate-1 repair round, operation 'floorplan-repair (gate1)'.
# ╚═══════════════════════════════════════════════════════════════════╝
# Repair instruction used by the Gate-1 fidelity loop. This is a QA/repair
# prompt, distinct from the extraction/design prompts in prompts.py.
_REPAIR_AGAINST_PLAN = (
    "A QA check compared geometry extracted from the attached 2D floor plan "
    "(IMAGE 1) against that plan and found these fidelity problems:\n"
    "{issues}\n\n"
    "Current extracted JSON:\n{current}\n\n"
    "Re-examine IMAGE 1 carefully and return a CORRECTED FloorPlan JSON that "
    "fixes every listed problem while staying faithful to the plan. Use the same "
    "schema and the same coordinate system (origin bottom-left, +x right, +y up, "
    "meters). Reproduce every wall, room, door and window in its true position. "
    "Return ONLY the JSON."
)
# ╚═══ END LIVE: _REPAIR_AGAINST_PLAN ══════════════════════════════════════╝

# ╔═══ LIVE ════════════════════════════════════════════════════════════╗
# ║ _geometry_facts()
# ║ source: backend/app/ai/guided_rendering.py  lines 97-143
# ║ Builds the EXACT GEOMETRY FACTS block -> {geometry_facts} in the
# ║ live guided render prompt.
# ╚═══════════════════════════════════════════════════════════════════╝
def _geometry_facts(floorplan_json: Optional[str]) -> str:
    """Distill the extracted FloorPlan JSON into short, countable facts for the
    render prompt. Raw coordinates are useless to an image model, but exact
    room/door/window COUNTS and sizes are precisely what it hallucinates.
    Fails open: any parse problem returns "" and the render proceeds."""
    if not floorplan_json:
        return ""
    try:
        import json

        data = json.loads(floorplan_json)
        rooms = data.get("rooms") or []
        openings = data.get("openings") or []
        doors = sum(1 for o in openings if o.get("type") == "door")
        windows = sum(1 for o in openings if o.get("type") == "window")
        outline = data.get("outline") or [
            p
            for w in (data.get("walls") or [])
            for p in (w.get("start"), w.get("end"))
            if p
        ]
        footprint = _bbox_size(outline)

        room_lines = []
        for r in rooms:
            size = _bbox_size(r.get("polygon") or [])
            name = r.get("name") or "room"
            room_lines.append(f"  - {name}" + (f": {size}" if size else ""))

        facts = [
            "\nEXACT GEOMETRY FACTS (machine-extracted from the CAD plan; "
            "IMAGE 1 was built from exactly these numbers, so your render "
            "must match them too):"
        ]
        if footprint:
            facts.append(f"- Building footprint (bounding box): {footprint}")
        facts.append(f"- Rooms: {len(rooms)}")
        facts.extend(room_lines)
        facts.append(f"- Doors: {doors} | Windows: {windows}")
        facts.append(
            "Before finalizing, COUNT the rooms, doors and windows in your "
            "render — each count must EQUAL the numbers above; no extras, "
            "none missing."
        )
        return "\n".join(facts) + "\n"
    except Exception:
        return ""
# ╚═══ END LIVE: _geometry_facts() ═════════════════════════════════════════╝

