# Stage-1 / Stage-2 rendering prompts, edit prompts, camera prompts.
#
# ANNOTATED VIEW — prompt text is byte-identical to the source; the only
# added lines are the LIVE / DEAD marker banners that wrap each prompt, plus
# this header and imports. Pristine un-annotated originals: ../llm_calls/
#
#   LIVE            = reachable and actually running in production today
#   DEAD            = defined but unreachable from any route/job in the app
#   UI-UNREACHABLE  = reachable via direct API call, but no UI path reaches it
#
# Source of truth: backend/app/ai/rendering.py
from dataclasses import dataclass


# ╔═══ DEAD ════════════════════════════════════════════════════════════╗
# ║ StyleSpec + to_prompt_table() — locked colour/material table
# ║ source: backend/app/ai/rendering.py  lines 88-186
# ║ Reason: the table only reaches a model through
# ║         STAGE_2B_APPLY_STYLE {style_spec_table}, which is dead, and
# ║         StyleSpec is only instantiated by the disabled
# ║         _extract_style_from_reference.
# ╚═══════════════════════════════════════════════════════════════════╝
# ═══════════════════════════════════════════════════════════════
# DATACLASSES
# ═══════════════════════════════════════════════════════════════

@dataclass
class StyleSpec:
    """
    Locked universal colour/material spec.
    No reference image is used anywhere in the active generation path.
    Defaults are pre-set to the approved standard style
    (SketchUp-style: near-black wall tops, bright walls, light grey floor, pale blue windows).
    """
    # -- Mandatory surfaces (approved universal theme) ----------------------
    wall_top_color:      str = "#111111"   # consistent near-black cap
    wall_color:          str = "#FAFAF7"   # clean matte off-white / neutral architectural white
    floor_color:         str = "#E8E6E0"   # light warm-grey microcement / polished concrete
    window_glass_color:  str = "#D7F1F7"   # bright pale blue glass
    window_frame_color:  str = "#4A4A4A"   # dark neutral grey frame
    bathroom_wall_color: str = "#FAFAF7"   # same clean matte off-white
    background_color:    str = "#FFFFFF"   # pure white

    # -- Lighting ----------------------------------------------------------
    lighting_temp_kelvin: str = "6500"
    lighting_description: str = "bright neutral white studio lighting, high exposure, clean SketchUp-style brightness, no warm tint, no beige cast, no yellow cast, no visible shadows"
    floor_material: str = "light warm-grey polished concrete / microcement floor, matte-to-satin finish"
    floor_texture: str = "subtle cloudy low-contrast microcement variation, clean architectural surface, no tile seams, no wood pattern, no marble veins, no speckles, no dirty patches, no noisy shadows"
    wall_material: str = "clean matte off-white architectural wall surface, smooth plain finish, minimal shading, crisp black SketchUp outlines, no wallpaper, no brick, no marble, no decorative texture"
    glass_material: str = "bright pale blue transparent architectural glass, neutral clean tint, subtle reflection, no green cast"
    wood_material: str = "warm wood veneer with subtle grain and realistic roughness"
    fabric_material: str = "clean woven fabric with gentle cushion softness"
    lighting_mood: str = "clean bright architectural render, high ambient light, neutral white illumination, no warm colour pollution, no dark corners, no visible AO"
    render_engine_style: str = "SketchUp/Lumion-style realistic architectural visualisation"

    # -- Furniture palette -------------------------------------------------
    wardrobe_color:         str = "#A07840"   # warm brown wood
    bed_frame_color:        str = "#FFFFFF"   # white platform
    bedding_color:          str = "#D8D8D8"   # light grey smooth fabric
    sofa_color:             str = "#808080"   # mid grey upholstery
    table_color:            str = "#4A3728"   # dark wood
    kitchen_cabinet_color:  str = "#D0D0D0"   # light grey lacquer
    kitchen_counter_color:  str = "#606060"   # dark stone

    extra_notes: str = ""

    def to_prompt_table(self) -> str:
        """
        Render as a numbered material table injected into Stage 2B.
        Hex values are treated as base/albedo colours, not flat paint fills.
        """
        rows = [
            ("01", "WALL TOPS",        self.wall_top_color,
             "PURE NEAR-BLACK #111111 — MUST appear on EVERY wall segment with zero omissions, including short walls, thin partitions, internal walls, enclosed-area walls, and tiny return walls. Razor-sharp SketchUp-style cap, no shading variation allowed"),
            ("02", "WALL FACES",        self.wall_color,
             f"{self.wall_material} — bright off-white, matte, not grey, not beige, not yellow"),
            ("03", "FLOOR SURFACE",     self.floor_color,
             f"{self.floor_material} base colour — {self.floor_texture}; ultra-subtle cloudy material variation is allowed, but no blotchy shadows or noisy grain"),
            ("04", "WINDOW GLASS",      self.window_glass_color,
             f"{self.glass_material} — fill every window cutout, not solid fill"),
            ("05", "WINDOW FRAME",      self.window_frame_color,
             "dark metal/aluminium frame — crisp thin profile, realistic edge shading"),
            ("06", "BATHROOM WALLS",    self.bathroom_wall_color,
             "same clean bright wall surface as regular walls — no tile, no teal, no special treatment"),
            ("07", "BACKGROUND",        self.background_color,
             "clean studio background outside footprint — neutral, unobtrusive, no grey cast"),
            ("08", "WARDROBES",         self.wardrobe_color,
             f"{self.wood_material} — subtle grain, realistic roughness, not flat brown"),
            ("09", "BED FRAMES",        self.bed_frame_color,
             "clean platform material — crisp bevels, hard silhouette, no floor shadow, no AO halo"),
            ("10", "BEDDING",           self.bedding_color,
             f"{self.fabric_material} — gentle folds, not noisy or cartoonish"),
            ("11", "SOFAS",             self.sofa_color,
             f"{self.fabric_material} upholstery — clean soft form, hard silhouette, no floor shadow, no AO halo"),
            ("12", "TABLES",            self.table_color,
             "wood/laminate tabletop — subtle grain or sheen, crisp edges"),
            ("13", "KITCHEN CABINETS",  self.kitchen_cabinet_color,
             "lacquer/laminate finish — crisp bevels, clean panels, no floor shadow, no AO halo"),
            ("14", "KITCHEN COUNTER",   self.kitchen_counter_color,
             "stone/laminate counter — clean surface, crisp edges, no noisy reflection, no shadow spill"),
        ]
        lines = [
            "╔═══════════════════════════════════════════════════════════════════════╗",
            "║  LOCKED BASE COLOUR + MATERIAL TABLE                                  ║",
            "║  Rules:                                                               ║",
            "║    • Use hex values as BASE / ALBEDO colours only.                     ║",
            "║    • Preserve each colour family with clean SketchUp-style materials.  ║",
            "║    • Use no visible floor shadows; keep floor variation nearly zero.  ║",
            "║    • Keep floors smooth: no white speckles or cloudy white patches.   ║",
            "║    • Keep walls/floors bright but not overexposed or pure white.      ║",
            "╠═══╦══════════════════╦═══════════╦══════════════════════════════════╣",
        ]
        for num, surface, colour, note in rows:
            lines.append(f"║{num:>3}║ {surface:<18}║ {colour:<9} ║ {note:<34}║")
        lines.append("╚═══╩══════════════════╩═══════════╩══════════════════════════════════╝")
        if self.lighting_description:
            lines.append(f"\nLIGHTING: {self.lighting_temp_kelvin}K — {self.lighting_description}")
        if self.extra_notes:
            lines.append(f"\nADDITIONAL NOTES FROM REFERENCE:\n{self.extra_notes}")
        lines.append(f"\nTEXTURE TARGET: {self.render_engine_style}; {self.lighting_mood}")
        return "\n".join(lines)
# ╚═══ END DEAD: StyleSpec + to_prompt_table() — locked colour/material table ╝

# ═══════════════════════════════════════════════════════════════
# PROMPTS
# ═══════════════════════════════════════════════════════════════

class Prompts:

    # ───────────────────────────────────────────────────────────
    # STAGE 1 — GEOMETRY ANCHOR  (v2: strict furniture slab rule)
    # ───────────────────────────────────────────────────────────


# ╔═══ DEAD ════════════════════════════════════════════════════════════╗
# ║ STAGE_1_GEOMETRY — Stage 1 white-box geometry anchor
# ║ source: backend/app/ai/rendering.py  lines 386-621
# ║ Reason: only reachable through RenderingService.generate_initial_render,
# ║         which is only called by ai_service.generate_3d / edit_render,
# ║         which are only called by services._execute_gen_3d_and_boq.
# ║         No route ever creates JobType.GEN_3D_AND_BOQ -> unreachable.
# ║ Evidence: generated_outputs/renders has 4 STAGE2_* files, newest
# ║         2026-06-12, vs 209 guided_render_* files up to 2026-07-28.
# ╚═══════════════════════════════════════════════════════════════════╝
    STAGE_1_GEOMETRY = """
        OUTPUT QUALITY STANDARD — MANDATORY:
        This output will be used as a professional architectural deliverable.
        Every line must be ruler-straight. Every angle must be exact.
        Walls must have clean, sharp, high-contrast edges.
        Result must look like professional CAD/SketchUp software output.

        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        ★ CAMERA — THE SINGLE MOST IMPORTANT RULE ★
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        YOU MUST PRODUCE A 3D MODEL — NOT A 2D PLAN.

        WHAT CORRECT LOOKS LIKE (pass = output this):
          ✓ You can clearly see wall HEIGHT on TWO exterior faces
          ✓ Camera is a true 3D isometric/axonometric view, not a near-vertical plan view
          ✓ Floor occupies roughly 50–65% of the canvas (not 80–90%)
          ✓ Wall faces are visible as rectangles, not thin lines
          ✓ The result looks like a SketchUp 3D model photo
          ✓ Interior of rooms visible through the open roof

        WHAT WRONG LOOKS LIKE (fail = REGENERATE, never output):
          ✗ Walls appear as thin outlines only — no visible height
          ✗ Floor fills 80% or more of the canvas
          ✗ Camera is too top-down or reads like a flat 2D plan
          ✗ The result looks like a 2D plan view with slight shading
          ✗ Rooms look like flat coloured rectangles on paper
          ✗ No visible exterior wall face at all

        ╔══════════════════════════════════════════════════════╗
        ║  FLAT-VIEW SELF-TEST — run this BEFORE outputting:  ║
        ║  Q1: Can you see wall HEIGHT on ≥ 2 exterior faces? ║
        ║      YES → continue | NO → REGENERATE               ║
        ║  Q2: Does the floor fill < 70% of canvas area?      ║
        ║      YES → continue | NO → REGENERATE (too flat)    ║
        ║  Q3: Do walls have clearly visible vertical faces?  ║
        ║      YES → continue | NO → REGENERATE               ║
        ║  Q4: Is the camera strongly 3D/isometric, not flat? ║
        ║      YES → continue | NO → REGENERATE               ║
        ║  ALL FOUR MUST BE YES. Any NO = regenerate.         ║
        ╚══════════════════════════════════════════════════════╝

        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        [STAGE 1/2: GEOMETRY ANCHOR — FULL FIDELITY LIFT]
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Convert this 2D floor plan into a clean white-box 3D model.
        Preserve geometry and numeric measurement/dimension annotations only. Do NOT preserve room/function labels such as BEDROOM, KITCHEN, AUDITORIUM, LOBBY, HALL, LOUNGE, CARPORCH, CAR PARK, TOILET, etc.

        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        GEOMETRY ACCURACY CHECKLIST
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        □ 1. Room COUNT matches floor plan exactly.
        □ 2. Every internal partition wall is present — including thin ones.
        □ 3. No wall moved, merged, or simplified.
        □ 4. Building footprint shape matches floor plan exactly.
        □ 5. Door openings.
        □ 6. Window cutouts in EVERY exterior wall where they exist.
        □ 7. Staircase rendered with visible step risers (if present).
        □ 8. Model NOT stretched or compressed horizontally.
        □ 9. No element closer than 10% to any canvas edge.
        □ 10. Camera passes the FLAT-VIEW SELF-TEST above.
        If any box fails — REGENERATE. Do NOT output a failing render.

        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        CANVAS PLACEMENT
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        • Model occupies NO MORE than 72% of canvas area.
        • Equal white margins: Top ≥ 13%, Bottom ≥ 13%, Left ≥ 13%, Right ≥ 13%.
        • Every dimension line, numeric dimension tag, and measurement callout: FULLY INSIDE canvas.
        • NO element closer than 10% to any canvas edge.

        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        TEXT / LABEL POLICY — DIMENSIONS ONLY
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        • Remove all room/function name labels from the 3D model.
        • Do NOT write labels such as ROOM, SMALL ROOM, AREA, BAR AREA,
          SERVICE AREA, CORRIDOR, STAIR, STAIRS, BED ROOM, BEDROOM, KITCHEN,
          AUDITORIUM, LOBBY, HALL, LOUNGE, CARPORCH, CAR PARK, BATHROOM,
          TOILET, STORE, OFFICE, LAWN, TERRACE, BALCONY, PORCH, TOTAL,
          OVERALL, WIDTH, DEPTH, etc.
        • Do NOT preserve title blocks, legends, north arrows, notes, or textual names.
        • Preserve/generate ONLY numeric architectural dimensions:
          room/area L×W values, wall dimensions, overall footprint dimensions,
          wall height, wall thickness, door/window width callouts.
        • If original text is a pure numeric dimension (e.g. 12'-0", 3.50 m,
          10×12, W=3'-0"), keep it. If it is a room/function name, remove it.
        • If an enclosed/usable area has NO written size in the original plan,
          add an estimated numeric L×W size in the same unit system and mark it (est.).
          This applies to every visually separated enclosed or usable region,
          including small edge regions and narrow regions.

        ╔══════════════════════════════════════════════════════════════╗
        ║  OCR-STYLE TEXT FILTER — APPLY BEFORE DRAWING ANY TEXT       ║
        ╠══════════════════════════════════════════════════════════════╣
        ║  The source floor plan often has two-line room labels like:  ║
        ║      BED ROOM                                                ║
        ║      9'-0" × 13'-0"                                         ║
        ║  In the 3D result this MUST become ONLY:                     ║
        ║      9'-0" × 13'-0"                                         ║
        ║  Delete the first/text name line completely.                 ║
        ║                                                              ║
        ║  FOR EVERY text cluster in the source image:                 ║
        ║    1) Split into separate lines.                             ║
        ║    2) Keep ONLY lines containing numbers + dimension units    ║
        ║       or dimension separators: ', ft, in, m, mm, ×, x, W=, H=║
        ║    3) Delete lines containing only words or room functions.   ║
        ║    4) Never re-type deleted words anywhere in the image.      ║
        ║                                                              ║
        ║  HARD BAN — these tokens may not appear anywhere:            ║
        ║  ROOM, SMALL ROOM, AREA, BAR AREA, SERVICE AREA, CORRIDOR,   ║
        ║  STAIR, STAIRS, BED, BEDROOM, BED ROOM, KITCHEN, HALL,       ║
        ║  TOILET, BATH, BATHROOM, BALCONY, AUDITORIUM, LOBBY,         ║
        ║  LOUNGE, CARPORCH, CAR PARK, PORCH, LAWN, TERRACE, OFFICE,   ║
        ║  STORE, FIRST FLOOR, GROUND FLOOR, FLOOR PLAN, PLAN, TOTAL,  ║
        ║  OVERALL, WIDTH, DEPTH.                                      ║
        ║                                                              ║
        ║  If a dimension is tied to a banned word, keep the numeric    ║
        ║  part only and discard the word.                              ║
        ╚══════════════════════════════════════════════════════════════╝

        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        STYLE RULES (Stage 1 — white-box only)
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        • Walls   : PURE NEUTRAL WHITE (#FFFFFF) — flat clean fill, zero texture, no beige/yellow tint
        • Floors  : VERY LIGHT NEUTRAL GREY (#EEEEEE) — flat matte, smooth and clean, zero blotches
        • NO shadows, NO ambient occlusion, NO materials, NO gradients
        • Clean black outline edges on wall tops only
        - Every wall edge, partition line, and building corner must have a
        razor-sharp 5px solid black stroke outline (#0A0A0A).
        - Apply stroke to: all exterior wall edges, all interior partition edges,
        window frame perimeters, door frame perimeters, staircase step edges.
        - Stroke must be continuous — no gaps, no fading, no anti-alias blur.
        - This is a hard CAD-style linework pass — like SketchUp's "edges ON" mode.
        • Solid pure white background (#FFFFFF)
        WALL TOP CAP COVERAGE — ABSOLUTE RULE:
        • EVERY wall must have a visible near-black top cap.
        • Do NOT omit wall-top caps on short wall pieces, internal partitions,
          narrow return walls, step-adjacent walls, enclosed-area walls, or tiny segments.
        • If a wall exists, it must show the dark top cap.
        • No wall may appear with only white side faces and no top cap.
        - SHARPNESS MANDATE — Stage 1 is a HARD-EDGE CAD model:
            Every wall edge, window frame, door frame, and staircase step
            must be rendered with maximum geometric precision.
            Anti-aliasing is FORBIDDEN on structural edges.
            Think: SketchUp model screenshot with edges ON, profiles ON,
            no post-processing blur, no soft rendering pass.
            Output must look like it was drawn with a ruler and set square.

        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        GEOMETRY RULES
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        • Trace EVERY wall exactly as positioned — no simplification
        • Maintain 100% aspect ratio — DO NOT stretch
        • All walls at strict 90-degree orthogonal angles
        • Preserve ALL internal partition walls including thin ones
        • Generate actual 3D doors: detect door positions from the original 2D floor plan
        and place hinged 3D door models at those exact positions. Each door should be
        slightly open (20–35 degrees) so the doorway is visually recognizable. Attach
        each door panel to the correct wall edge.

        ╔══════════════════════════════════════════════════════════════╗
        ║  DOOR ARC LINES — ABSOLUTE ZERO TOLERANCE                    ║
        ║  THIS APPLIES TO ALL SPACE TYPES INCLUDING COMMERCIAL        ║
        ╠══════════════════════════════════════════════════════════════╣
        ║  The 2D floor plan shows curved quarter-circle arc lines     ║
        ║  to indicate door swing direction. These are 2D drafting     ║
        ║  symbols ONLY. They DO NOT EXIST in a 3D model.             ║
        ║                                                              ║
        ║  STRICTLY FORBIDDEN — zero exceptions:                       ║
        ║    ✗ Any curved arc line drawn on the floor                  ║
        ║    ✗ Any quarter-circle sweep line at a doorway              ║
        ║    ✗ Any thin curved line near any door opening              ║
        ║    ✗ Any door swing indicator of any kind on the floor       ║
        ║    ✗ Any semicircle, arc, or curved floor marking            ║
        ║                                                              ║
        ║  THIS INCLUDES:                                              ║
        ║    ✗ Cinema/auditorium entry doors                           ║
        ║    ✗ Emergency exit doors                                    ║
        ║    ✗ Any entry, exit, interior, or service door               ║
        ║    ✗ Every single door in the plan — no exceptions           ║
        ║                                                              ║
        ║  WHAT A DOOR LOOKS LIKE IN 3D (the ONLY acceptable form):   ║
        ║    ✓ A flat rectangular door panel attached to wall edge     ║
        ║    ✓ Door panel rotated 20–35 degrees open                   ║
        ║    ✓ Clean floor surface beneath — no lines, no curves       ║
        ║                                                              ║
        ║  MANDATORY SELF-CHECK before outputting:                     ║
        ║    Scan EVERY doorway in the entire building.                ║
        ║    Count the doors. Check each one individually.             ║
        ║    If even ONE curved line exists on the floor → REMOVE      ║
        ║    ALL arc lines and regenerate. Zero tolerance.             ║
        ╚══════════════════════════════════════════════════════════════╝
        Windows as rectangular cutouts filled with #D7F1F7 bright pale blue glass.
        Add thin #4A4A4A frame border around each pane.
          DO NOT leave windows empty or white.
        • Render staircase with visible step risers if present


        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        ╔══════════════════════════════════════════════════════════════╗
        ║  FURNITURE SYMBOL PROCESSING — CRITICAL STAGE 1 RULE        ║
        ╠══════════════════════════════════════════════════════════════╣
        ║  Stage 1 renders GEOMETRY ONLY.                              ║
        ║  ANY furniture/fixture symbol in the floor plan is           ║
        ║  rendered as a FLAT 2D GREY SLAB on the floor — NOTHING MORE.║
        ╠══════════════════════════════════════════════════════════════╣
        ║  STRICT SLAB RULES:                                          ║
        ║    ✓ Slab height = 1 px (effectively flat/2D on floor)       ║
        ║    ✓ Slab fill = #C0C0C0 (medium grey — flat, no texture)    ║
        ║    ✓ Slab footprint = EXACT match to floor plan symbol size  ║
        ║    ✓ Slab position = EXACT match to floor plan symbol pos    ║
        ║
        ╠══════════════════════════════════════════════════════════════╣
        ║  STRICTLY FORBIDDEN IN STAGE 1:                              ║
        ║    ✗ 3D bed shapes, mattress volumes, headboards             ║
        ║    ✗ 3D sofa shapes or cushion volumes                       ║
        ║    ✗ 3D wardrobe / cabinet volumes                           ║
        ║    ✗ Any object with height > 1px                            ║
        ║    ✗ Any furniture NOT drawn in the floor plan               ║
        ║    ✗ Inference: "BED ROOM" ≠ add a bed slab unless drawn    ║
        ╠══════════════════════════════════════════════════════════════╣
        ║  IF ZERO furniture symbols exist in the floor plan:          ║
        ║    Every floor surface MUST be 100% EMPTY. Absolutely zero  ║
        ║    objects of any kind. Stage 2 will decide what to add.    ║
        ╚══════════════════════════════════════════════════════════════╝


        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        OUTER BUILDING DIMENSIONS
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Place thin black dimension lines with tick endpoints OUTSIDE the
        building footprint (not overlapping any wall).
        Label total Width on top + bottom; total Depth on left + right.
        Keep all dimension lines within the canvas boundary.

        TITLE BLOCK / ROOM TEXT: do NOT reproduce title blocks, floor titles, room/function labels, or any word-only text. Only numeric dimensions and measurement callouts are allowed. Example: 'FIRST FLOOR PLAN' must be deleted; '50'' may remain.
    """
# ╚═══ END DEAD: STAGE_1_GEOMETRY — Stage 1 white-box geometry anchor ══════╝

# ╔═══ DEAD ════════════════════════════════════════════════════════════╗
# ║ STAGE_2A_ANALYZE_FLOORPLAN — image -> instructions (JSON)
# ║ source: backend/app/ai/rendering.py  lines 627-688
# ║ Reason: only reachable through RenderingService.generate_initial_render,
# ║         which is only called by ai_service.generate_3d / edit_render,
# ║         which are only called by services._execute_gen_3d_and_boq.
# ║         No route ever creates JobType.GEN_3D_AND_BOQ -> unreachable.
# ║ Evidence: generated_outputs/renders has 4 STAGE2_* files, newest
# ║         2026-06-12, vs 209 guided_render_* files up to 2026-07-28.
# ╚═══════════════════════════════════════════════════════════════════╝
    STAGE_2A_ANALYZE_FLOORPLAN = """
        You are an expert architectural analyst. Carefully study this 2D floor plan.

        Return ONLY a JSON object — no markdown fences, no explanation:
        {
          "space_type": "<residential_house | residential_apartment | office | retail_shop | restaurant | cafe | cinema | hotel | clinic | gym | warehouse | mixed_use>",
          "subtype_notes": "<e.g. '3-bedroom apartment'>",
          "key_rooms": ["<room1>", "<room2>", "..."],
          "scale": "<small | medium | large>",
          "style_recommendation": "<modern_residential | retail_commercial>",
          "has_furniture": "<true | false>",
          "furniture_coverage": "<full | partial | none>",
          "furniture_by_room": {"<room_name>": ["<item1>", "<item2>"], "...": []},
          "has_dimensions": "<true | false>",
          "dimension_coverage": "<full | partial | none>",
          "furniture_items": ["<item1>", "..."],
          "areas_with_dimensions": ["<area/room where numeric LxW or dimension is already written>", "..."],
          "areas_missing_dimensions": ["<area/room/balcony/corridor/stair/porch/car park/usable zone with no numeric LxW written>", "..."],
          "all_enclosed_or_usable_areas": ["<every room/area/zone including balconies, stairs, passages, porches, car parks>", "..."],
          "unit_system": "<metric | imperial | unknown>",
          "dominant_unit": "<m | mm | ft | in | unknown>",
          "wall_height_estimate": "<e.g. '9ft-0in'>",
          "wall_thickness_ext": "<e.g. '9in'>",
          "wall_thickness_int": "<e.g. '4.5in'>",
          "door_width_typical": "<e.g. '3ft-0in'>",
          "window_width_typical": "<e.g. '3ft-0in'>"
        }

        Definitions:
        • "has_furniture"      : true ONLY if actual drawn furniture/fixture SYMBOLS or OUTLINES
                                 exist as graphical elements in the floor plan image.
                                 A room NAME like "BED ROOM", "KITCHEN", "Zimmer", "Schlafzimmer"
                                 is NOT furniture. Text labels are NEVER furniture.
                                 Only count items that are DRAWN as shapes/outlines
                                 (e.g. a rectangle with rounded corners = bed symbol,
                                  circles = toilet/sink, hatched rectangle = wardrobe).
        • "furniture_coverage" : full = nearly all rooms have drawn symbols; partial = some rooms;
                                 none = zero drawn symbols (only text labels exist).
        • "furniture_by_room"  : ONLY list rooms where actual drawn symbols exist.
                                 DO NOT list rooms just because their name implies furniture.
                                 e.g. if "BED ROOM" has no drawn bed symbol → do NOT list it.
        • "has_dimensions"     : true ONLY if explicit numeric values (m, mm, ft, ") appear.
        • "dimension_coverage" : full = nearly all rooms/areas labelled; partial = some; none = zero.
        • "areas_with_dimensions" : include only zones that already have a visible numeric size/dimension.
        • "areas_missing_dimensions" : include EVERY usable/enclosed zone that lacks a numeric L×W size,
                                  including balcony, corridor, passage, porch, car porch, car park, stair,
                                  landing, lobby, terrace, lawn, utility, store, shaft/open area if present.
                                  If a small enclosed/usable region has no visible numeric L×W size,
                                  it MUST be listed here.
        • "all_enclosed_or_usable_areas" : complete coverage list. Count EVERY visually separated
                                  enclosed or usable region, including very small rooms, tiny pockets,
                                  stair landings, narrow passages, service spaces, edge areas, entry pockets,
                                  irregular niches, balconies, porches, shafts/open usable zones,
                                  and partial-width spaces. Do not skip an area because it is small or hard to name.
        • "unit_system"        : detect from labels. None → "metric" if European, "imperial" if US-style.
        • "dominant_unit"      : unit used most. Guess from context if not labelled.
        • wall/door/window estimates: estimate from scale bar or proportion if not explicit.

        CRITICAL: Be extremely conservative with has_furniture. Default to false if unsure.
        A floor plan with only room name labels and wall lines has NO furniture.
        Only return has_furniture=true if you can see actual drawn object symbols.
    """
# ╚═══ END DEAD: STAGE_2A_ANALYZE_FLOORPLAN — image -> instructions (JSON) ═╝

# ╔═══ DEAD ════════════════════════════════════════════════════════════╗
# ║ STAGE_2A_EXTRACT_STYLE
# ║ source: backend/app/ai/rendering.py  lines 694-741
# ║ Reason: zero references. The prompt text itself says 'DISABLED LEGACY
# ║         PROMPT'. _extract_style_from_reference returns StyleSpec()
# ║         without making any model call.
# ╚═══════════════════════════════════════════════════════════════════╝
    STAGE_2A_EXTRACT_STYLE = """
        DISABLED LEGACY PROMPT. Do not use this prompt in the active pipeline.
        This pipeline uses the fixed universal no-reference style only.

        You are an expert architectural visualisation material analyst.
        Study this reference render image VERY carefully.
        Extract base surface colours, material behaviour, texture feel, lighting, and render-engine style.

        Return ONLY a JSON object — no markdown fences, no explanation:
        {
          "wall_top_color": "<hex e.g. #1A1A1A>",
          "wall_color": "<hex>",
          "floor_color": "<hex>",
          "floor_material": "<clean smooth architectural floor | hardwood | marble | carpet>",
          "floor_texture": "<brief description of smoothness, evenness, and noise control>",
          "wall_material": "<brief description of pure neutral white matte wall behaviour with no tint or broad variation>",
          "window_glass_color": "<hex>",
          "glass_material": "<brief description of tint, transparency, reflection>",
          "window_frame_color": "<hex>",
          "bathroom_wall_color": "<hex — use wall_color value, do NOT extract teal/coloured tile>",
          "background_color": "<hex>",
          "lighting_temp_kelvin": "<number>",
          "lighting_description": "<brief>",
          "lighting_mood": "<brief description of shadows, AO, contrast, ambience>",
          "render_engine_style": "<e.g. SketchUp/Lumion realistic architectural render>",
          "wardrobe_color": "<hex>",
          "wood_material": "<brief description of grain, veneer, roughness>",
          "bed_frame_color": "<hex>",
          "bedding_color": "<hex>",
          "fabric_material": "<brief description of weave, softness, wrinkles>",
          "sofa_color": "<hex>",
          "table_color": "<hex>",
          "kitchen_cabinet_color": "<hex>",
          "kitchen_counter_color": "<hex>",
          "extra_notes": "<1-3 sentences on distinctive style features>"
        }

        Rules:
        • Sample the dominant base/albedo colour for each surface directly from image pixels.
          DO NOT flatten the style into solid fills; preserve material and lighting cues.
        • Extract visible texture/material qualities: clean wall smoothness, light floor finish,
          glass reflection/transparency, wood/fabric grain, clean edge treatment, bevel treatment.
        • If a surface type is NOT visible: use architectural defaults:
            wall_top: #111111 | walls: #FFFFFF | floor: #EEEEEE
            window_glass: #D7F1F7 | frame: #4A4A4A | bathroom: #FFFFFF
            background: #FFFFFF
        • Hex values: exactly 7 chars — # + 6 UPPERCASE hex digits.
    """
# ╚═══ END DEAD: STAGE_2A_EXTRACT_STYLE ════════════════════════════════════╝

# ╔═══ DEAD ════════════════════════════════════════════════════════════╗
# ║ _GEOMETRY_LOCK_HEADER
# ║ source: backend/app/ai/rendering.py  lines 747-774
# ║ Reason: only prepended to STAGE_2B_APPLY_STYLE and
# ║         STAGE_2B_APPLY_STYLE_NO_REF, both of which are dead.
# ╚═══════════════════════════════════════════════════════════════════╝
    _GEOMETRY_LOCK_HEADER = """
╠════════════════════════════════════════════════════════════════════╣
║  STEP 1 — GEOMETRY LOCK (layout only)                              ║
╠════════════════════════════════════════════════════════════════════╣
║  From IMAGE 1 and original floor plan, preserve EXACTLY:          ║
║    Room count, relative positions, wall layout, footprint shape   ║
║    Building rotation direction, door/window positions             ║
║    Numeric dimension values/callouts only                         ║
║  DO NOT preserve any word-only text from IMAGE 1.                 ║
║  FORBIDDEN: moving walls, changing rooms, rotating building       ║
╠════════════════════════════════════════════════════════════════════╣
║  TEXT FILTER — NUMBERS ONLY                                       ║
╠════════════════════════════════════════════════════════════════════╣
║  Before output, scan all visible text in IMAGE 1.                  ║
║  Keep ONLY numeric dimension strings: examples 9'-0" × 13'-0",    ║
║  3.50 × 3.00 m, 50', 45', W = 3ft-0in, H = 9ft-0in.               ║
║  Delete every word/function/title token even when it is next to    ║
║  a dimension. Example: 'BED ROOM 9'-0" × 13'-0"' becomes only      ║
║  '9'-0" × 13'-0"'.                                                ║
║  Never write: ROOM, SMALL ROOM, AREA, BAR AREA, SERVICE AREA,     ║
║  CORRIDOR, STAIR, STAIRS, BEDROOM, BED ROOM, KITCHEN, HALL,       ║
║  TOILET, BATHROOM, AUDITORIUM, LOBBY, LOUNGE, CARPORCH, CAR PARK, ║
║  BALCONY, PORCH, LAWN, FLOOR PLAN, FIRST FLOOR PLAN,              ║
║  GROUND FLOOR PLAN, OFFICE, TOTAL, OVERALL, WIDTH, DEPTH.         ║
║  Allowed visible text only: numeric dimensions and measurement     ║
║  callouts. Any other text = failed render.                         ║
╚════════════════════════════════════════════════════════════════════╝
"""
# ╚═══ END DEAD: _GEOMETRY_LOCK_HEADER ═════════════════════════════════════╝

# ╔═══ LIVE ════════════════════════════════════════════════════════════╗
# ║ _ANTI_SHADOW_BLOB_FINAL_CHECK
# ║ source: backend/app/ai/rendering.py  lines 782-811
# ║ Appended to the chat-edit and area-edit prompts at runtime.
# ╚═══════════════════════════════════════════════════════════════════╝
    _ANTI_SHADOW_BLOB_FINAL_CHECK = """
    ╔══════════════════════════════════════════════════════════════╗
    ║  ★  FINAL RENDER SELF-CHECK — MANDATORY BEFORE OUTPUT  ★     ║
    ╠══════════════════════════════════════════════════════════════╣
    ║  REJECT AND REGENERATE if any are visible:                   ║
    ║                                                              ║
    ║    ✗ Pixelated or blocky shadows                             ║
    ║    ✗ Speckled / noisy floor texture                          ║
    ║    ✗ White scattered pixels around dimension text             ║
    ║    ✗ Broken, blurry, glowing, or partially erased dimension text║
    ║    ✗ Cloud-like grey/white floor patches                     ║
    ║    ✗ Dirty ambient-occlusion smudges                          ║
    ║    ✗ Radial halos around walls, windows, doors, or dimension text║
    ║    ✗ Large dark patches cast by walls across floors           ║
    ║    ✗ Curved door swing arc lines on the floor (ANY door,     ║
    ║      ANY room type — residential OR commercial)              ║
    ║                                                              ║
    ║  REQUIRED OUTPUT:                                            ║
    ║    ✓ Wall tops remain accurate near-black caps                ║
    ║    ✓ Every wall/partition edge has a crisp 5px dark stroke  ║
    ║    ✓ No edge is soft, faded, or dissolved into material       ║
    ║    ✓ Wall faces look bright, clean, and almost flat           ║
    ║    ✓ Floor remains clean smooth light grey architectural floor║
    ║    ✓ Dimension text is crisp black CAD-style overlay text      ║
    ║    ✓ Texture never crosses over or damages dimension text      ║
    ║    ✓ No visible ambient occlusion or floor shadow scatter     ║
    ║    ✓ Every material boundary is razor-sharp — no blurred edges      ║
    ║    ✓ Glass colour fully contained within frame — zero floor bleed   ║
    ╚══════════════════════════════════════════════════════════════╝
    """
# ╚═══ END LIVE: _ANTI_SHADOW_BLOB_FINAL_CHECK ═════════════════════════════╝

# ╔═══ LIVE ════════════════════════════════════════════════════════════╗
# ║ _STRICT_EDIT_SCOPE_LOCK
# ║ source: backend/app/ai/rendering.py  lines 813-878
# ║ Injected into both edit prompts via _strict_edit_scope_lock().
# ╚═══════════════════════════════════════════════════════════════════╝
    _STRICT_EDIT_SCOPE_LOCK = """
╔══════════════════════════════════════════════════════════════════════╗
║  EDIT SCOPE LOCK — ABSOLUTE RULE                                    ║
╠══════════════════════════════════════════════════════════════════════╣
║  You are editing an existing 3D render, NOT regenerating a plan.     ║
║  Apply ONLY the user's explicitly requested instruction(s).          ║
║  Do NOT make additional, inferred, stylistic, corrective, or         ║
║  automatic changes.                                                  ║
╠══════════════════════════════════════════════════════════════════════╣
║  USER INSTRUCTION:                                                   ║
║  {instruction}                                                       ║
╠══════════════════════════════════════════════════════════════════════╣
║  STRICT RULES:                                                       ║
║    1. Perform only the exact requested edit(s).                      ║
║    2. Do not alter anything the user did not explicitly ask to       ║
║       change.                                                        ║
║    3. Do not infer extra improvements.                               ║
║    4. Do not redesign the scene.                                     ║
║    5. Do not restyle materials, colors, lighting, or objects unless  ║
║       explicitly requested.                                          ║
║    6. Do not regenerate the whole image from scratch if a local edit ║
║       is enough.                                                     ║
║    7. Preserve the current 3D render as-is except for the requested  ║
║       change.                                                        ║
╠══════════════════════════════════════════════════════════════════════╣
║  PRESERVE EXACTLY UNLESS USER EXPLICITLY REQUESTS OTHERWISE:         ║
║    • overall layout, room positions, wall positions, wall thickness  ║
║    • camera angle, perspective, crop, framing, scale                 ║
║    • floor material and floor color                                  ║
║    • wall colors, toilet/bathroom wall colors, wall top caps         ║
║    • window glass color and window frame style                       ║
║    • door/window positions, stairs, openings                         ║
║    • dimension annotations already visible                           ║
║    • lighting style, brightness, exposure, shadow behavior           ║
║    • existing furniture and textures/material theme                  ║
║    • sharp outlines / SketchUp edge clarity                          ║
╠══════════════════════════════════════════════════════════════════════╣
║  TEXT / LABEL PROTECTION:                                            ║
║    ✗ Do NOT add room labels.                                         ║
║    ✗ Do NOT add function labels.                                     ║
║    ✗ Do NOT add title blocks.                                        ║
║    ✗ Do NOT add legends.                                             ║
║    ✗ Do NOT add random text.                                         ║
║    ✗ Do NOT restore 2D plan annotations.                             ║
║    ✗ Do NOT add labels unless user explicitly asked for labels.      ║
╠══════════════════════════════════════════════════════════════════════╣
║  NO-UNREQUESTED-CHANGE EXAMPLES:                                     ║
║    • If user says "add furniture", ONLY add furniture.               ║
║      Do NOT change toilet wall colors, floor, walls, windows,        ║
║      camera, labels, dimensions, or lighting.                        ║
║    • If user says "change floor", ONLY change floor.                 ║
║      Do NOT change walls, windows, toilet colors, furniture, labels. ║
║    • If user says "add sofa", ONLY add that sofa.                    ║
║      Do NOT add extra decor or other furniture.                      ║
║    • If user says "make walls darker", ONLY change walls.            ║
║      Do NOT change floor, windows, furniture, labels, camera.        ║
╠══════════════════════════════════════════════════════════════════════╣
║  FINAL SELF-CHECK BEFORE OUTPUT:                                     ║
║    □ Did I apply only the requested instruction(s)?                  ║
║    □ Did I avoid changing unrelated colors/materials?                ║
║    □ Did I preserve toilet/bathroom wall colors unless requested?    ║
║    □ Did I preserve floor/walls/windows/camera unless requested?     ║
║    □ Did I avoid adding labels/text?                                 ║
║  If any answer is NO, regenerate and fix before output.              ║
╚══════════════════════════════════════════════════════════════════════╝
    """
# ╚═══ END LIVE: _STRICT_EDIT_SCOPE_LOCK ═══════════════════════════════════╝

# ╔═══ DEAD ════════════════════════════════════════════════════════════╗
# ║ _ZERO_FURNITURE_MANDATE
# ║ source: backend/app/ai/rendering.py  lines 885-929
# ║ Reason: only returned by _build_furniture_mandate, which is only
# ║         called by apply_universal_style (dead).
# ╚═══════════════════════════════════════════════════════════════════╝
    _ZERO_FURNITURE_MANDATE = """
╔══════════════════════════════════════════════════════════════════╗
║  ██  FURNITURE POLICY: ZERO FURNITURE — ABSOLUTE RULE  ██        ║
╠══════════════════════════════════════════════════════════════════╣
║  The original floor plan contains NO drawn furniture symbols.    ║
║  Therefore every floor surface in EVERY room = 100% EMPTY.      ║
╠══════════════════════════════════════════════════════════════════╣
║  ★★★  ROOM NAMES ARE NOT FURNITURE INSTRUCTIONS  ★★★             ║
║                                                                  ║
║  These room labels do NOT authorise adding ANYTHING:             ║
║    "BED ROOM" / "BEDROOM" / "Schlafzimmer"                      ║
║       → do NOT add: bed, wardrobe, nightstand, or any item      ║
║    "KITCHEN" / "Küche"                                          ║
║       → do NOT add: cabinets, counters, appliances, sink        ║
║    "Zimmer" / "HALL" / "LIVING ROOM" / "Wohnzimmer"             ║
║       → do NOT add: sofas, tables, chairs, or any furniture     ║
║    "TOILET" / "BAD" / "BATHROOM"                                ║
║       → do NOT add: toilet, sink, bathtub, or any fixture       ║
║    "BAR" / "LOUNGE" / "AUDITORIUM"                              ║
║       → do NOT add: seats, stools, bar counter, or any element  ║
║    ANY label name whatsoever                                     ║
║       → do NOT add ANY object based on what the name implies    ║
╠══════════════════════════════════════════════════════════════════╣
║  THE ONLY VALID REASON to render an object in a room:            ║
║    A physical drawn symbol for that object existed as a          ║
║    graphical element in the ORIGINAL FLOOR PLAN IMAGE.           ║
║    No drawn symbol in original = zero objects in that room.      ║
╠══════════════════════════════════════════════════════════════════╣
║  COMPLETELY FORBIDDEN in every room:                             ║
║    ✗ Beds, mattresses, pillows, headboards                      ║
║    ✗ Sofas, armchairs, chairs, stools, benches                  ║
║    ✗ Tables, desks, counters, islands, bar counters             ║
║    ✗ Wardrobes, closets, shelves, cabinets of any kind          ║
║    ✗ Kitchen appliances or kitchen fittings of any kind         ║
║    ✗ Bathroom fixtures (toilet, sink, tub, shower, mirror)      ║
║    ✗ Cinema/theatre seats or auditorium rows                    ║
║    ✗ Rugs, curtains, plants, lamps, art, decorations            ║
║    ✗ Any object, prop, or accessory whatsoever                  ║
╠══════════════════════════════════════════════════════════════════╣
║  SELF-CHECK before outputting — if ANY fails, remove the item:  ║
║    □ Every room floor is completely empty (only floor colour)?   ║
║    □ Zero objects added based on a room name?                    ║
║    □ Zero objects added by inference from space type?            ║
╚══════════════════════════════════════════════════════════════════╝
"""
# ╚═══ END DEAD: _ZERO_FURNITURE_MANDATE ═══════════════════════════════════╝

# ╔═══ DEAD ════════════════════════════════════════════════════════════╗
# ║ _FURNITURE_MIRRORING_MANDATE
# ║ source: backend/app/ai/rendering.py  lines 932-953
# ║ Reason: same as _ZERO_FURNITURE_MANDATE.
# ╚═══════════════════════════════════════════════════════════════════╝
    _FURNITURE_MIRRORING_MANDATE = """
╔══════════════════════════════════════════════════════════════╗
║  ⚠  FURNITURE POLICY: FULL MIRRORING                        ║
║  Replace each grey placeholder slab with the matching piece. ║
╠══════════════════════════════════════════════════════════════╣
║  RULES:                                                      ║
║    ✓ Replace EACH grey slab with correct furniture piece     ║
║    ✓ Match slab POSITION and FOOTPRINT SIZE exactly          ║
║    ✓ Apply colours from LOCKED STYLE SPEC above              ║
║    ✗ DO NOT add furniture outside placeholder positions      ║
║    ✗ DO NOT invent furniture not in the plan                 ║
╠══════════════════════════════════════════════════════════════╣
║  Furniture detected in source plan:                          ║
║  {furniture_list}
║                                                              ║
║  FURNITURE SELF-CHECK:                                       ║
║    □ Every slab replaced with correct piece?                 ║
║    □ No furniture added outside slab positions?              ║
║    □ All furniture colours match the STYLE SPEC?             ║
║    □ No specular noise or rough texture on furniture?        ║
╚══════════════════════════════════════════════════════════════╝
"""
# ╚═══ END DEAD: _FURNITURE_MIRRORING_MANDATE ══════════════════════════════╝

# ╔═══ DEAD ════════════════════════════════════════════════════════════╗
# ║ _PARTIAL_FURNITURE_MANDATE
# ║ source: backend/app/ai/rendering.py  lines 955-975
# ║ Reason: same as _ZERO_FURNITURE_MANDATE.
# ╚═══════════════════════════════════════════════════════════════════╝
    _PARTIAL_FURNITURE_MANDATE = """
╔══════════════════════════════════════════════════════════════╗
║  ⚠  FURNITURE POLICY: GREY-SLAB-SPECIFIC (partial)          ║
╠══════════════════════════════════════════════════════════════╣
║  For each internal numeric entry below, the rule is ABSOLUTE:║
╠══════════════╦═══════════════════════════════════════════════╣
║    ID         ║  ACTION                                       ║
╠══════════════╬═══════════════════════════════════════════════╣
{room_table}╠══════════════╩═══════════════════════════════════════════════╣
║  HARD RULES:                                                 ║
║    ✓ FURNISHED entries: replace grey slabs at exact positions║
║    ✓ Apply colours from LOCKED STYLE SPEC                    ║
║    ✗ EMPTY entries: zero objects — NONE — not even a rug     ║
║    ✗ DO NOT infer any object from text or space type         ║
╠══════════════════════════════════════════════════════════════╣
║  FURNITURE SELF-CHECK:                                       ║
║    □ Every FURNISHED entry has its slabs replaced?           ║
║    □ Every EMPTY entry has zero objects on the floor?        ║
║    □ No furniture added outside grey slab positions?         ║
╚══════════════════════════════════════════════════════════════╝
"""
# ╚═══ END DEAD: _PARTIAL_FURNITURE_MANDATE ════════════════════════════════╝

# ╔═══ LIVE ════════════════════════════════════════════════════════════╗
# ║ LIGHTING_ENVIRONMENT
# ║ source: backend/app/ai/rendering.py  lines 981-1049
# ║ Appended to the chat-edit and area-edit prompts at runtime.
# ║ (It is ALSO referenced by the dead Stage 2B templates - ignore those.)
# ╚═══════════════════════════════════════════════════════════════════╝
    LIGHTING_ENVIRONMENT = """
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        RENDER QUALITY TARGET
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Target look: clean SketchUp-style architectural visualisation.
        Bright, sharp, clean, minimal, and noise-free.
        NOT moody. NOT shadow-heavy. NOT dirty. NOT grainy.

        LIGHTING:
          • Bright high-key neutral white daylight — 6500K.
          • Every room fully and evenly lit like a clean SketchUp viewport export.
          • White surfaces must remain neutral white — not ivory, not cream, not beige, not yellow.
          • Floor receives maximum diffuse light.
          • No room darker than 95% of maximum brightness.
          • Shadows: ZERO visible shadows across the floor.
          • The only allowed dark mark at wall bases is a crisp 1px floor/wall edge stroke, not a shadow.

        ╔══════════════════════════════════════════════════════════════╗
        ║  SHADOW / CLEAN FLOOR RULES — ABSOLUTE ZERO TOLERANCE       ║
        ╠══════════════════════════════════════════════════════════════╣
        ║  ALLOWED:                                                   ║
        ║    ✓ Only a crisp 5px floor/wall edge stroke exactly on the boundary     ║
        ║    ✓ No ambient occlusion, no soft contact shadow, and no shadow spread beyond the wall edge║
        ║                                                             ║
        ║  FORBIDDEN:                                                 ║
        ║    ✗ Broad soft shadows across open floor areas             ║
        ║    ✗ Speckled floor noise                                   ║
        ║    ✗ Grainy concrete texture                                ║
        ║    ✗ Cloudy grey/white floor blobs                          ║
        ║    ✗ Dirty AO smudges                                       ║
        ║    ✗ Random scratches, stains, grunge, dust, mottling       ║
        ║    ✗ White sparkle-like scatter on the floor                ║
        ║    ✗ Uneven bright/dark floor patches                       ║
        ║    ✗ Salt-and-pepper shadow noise                           ║
        ║    ✗ Stippled grey dots                                     ║
        ║    ✗ Scattered grey pixels                                  ║
        ║    ✗ Granular shadow texture                                ║
        ║    ✗ Shadow dust around furniture or walls                  ║
        ║    ✗ White noisy islands on the floor                       ║
        ║    ✗ Grey halo around walls or seating rows                 ║
        ║    ✗ Beige cast on walls                                    ║
        ║    ✗ Cream/ivory tint on white surfaces                     ║
        ║    ✗ Yellowish light pollution on floors or walls           ║
        ║    ✗ Warm brownish overall colour grading                   ║
        ╚══════════════════════════════════════════════════════════════╝

        FLOOR MATERIAL RULE:
          Default floor must stay light warm-grey polished concrete / microcement.
          It should have a matte-to-satin architectural finish with subtle cloudy
          low-contrast material variation, like the reference floor.
          Do NOT make it plain pure white, dark concrete, wood, marble, tile grid, carpet,
          or glossy stone unless the user explicitly asks.
          No noisy concrete grain, no visible particles, no speckling, no dirty patches,
          no cloudy SHADOW shapes, no salt-and-pepper noise, no grey stippling,
          and no scattered pixels.

        SHARPNESS + LINEWORK:
          • Every wall edge must remain crisp and dark.
          • Use sharp 5px dark stroke on visible wall edges.
          • No blurry boundaries.
          • No glow.
          • No feathered shadow edges.
          • Linework must remain clearly visible on top of materials.

        WINDOWS:
          • Fill EVERY window opening with the glass colour from STYLE SPEC.
          • Add thin frame border per STYLE SPEC.
          • NO empty windows. NO white windows.
    """
# ╚═══ END LIVE: LIGHTING_ENVIRONMENT ══════════════════════════════════════╝

# ╔═══ DEAD ════════════════════════════════════════════════════════════╗
# ║ STAGE_2B_APPLY_STYLE — reference-guided compositor
# ║ source: backend/app/ai/rendering.py  lines 1057-1307
# ║ Reason: ZERO references anywhere in the codebase. Not even the dead
# ║         two-stage path calls it - apply_style_transfer routes to
# ║         apply_universal_style, which uses the NO_REF variant.
# ║         251 lines that have never run.
# ╚═══════════════════════════════════════════════════════════════════╝
    STAGE_2B_APPLY_STYLE = (
        _GEOMETRY_LOCK_HEADER
        + """
        [STAGE 2/2: STYLE COMPOSITOR — Reference-guided]

        You receive:
          IMAGE 1 — 3D white-box skeleton (GEOMETRY LOCK — see header above).
          IMAGE 2 — Reference render (visual atmosphere guide only).
                    The LOCKED STYLE SPEC table below is the authoritative colour source.

        Space context:
          • Space type : {space_type}
          • Subtype    : {subtype_notes}
          • Count      : use IMAGE 1 visually; do not write any area names.

        ════════════════════════════════════════════════════════════
        LOCKED STYLE SPECIFICATION — AUTHORITATIVE COLOUR SOURCE
        (Extracted from reference — override EVERYTHING with these values)
        ════════════════════════════════════════════════════════════
        {style_spec_table}
        ════════════════════════════════════════════════════════════
        CLEAN RENDER LOCK — MUST MATCH TARGET OUTPUT
        ════════════════════════════════════════════════════════════
        The final render must stay extremely clean, bright, and sharp.
        • Remove broad shadows and dirty shading.
        • Floor must be smooth, flat, very light grey, and visually even.
        • Walls must stay pure neutral white.
        • No cloudy floor patches.
        • No dirty corner darkening.
        • No visible ambient occlusion except the tiniest wall-base grounding.
        • Overall look must be a clean SketchUp export, not a realistic moody render.
        • Strokes/edges must stay sharp and clearly visible.

        ════════════════════════════════════════════════════════════
        WALL WHITENESS LOCK:
        • All wall faces must be pure neutral white #FFFFFF.
        • No cream, beige, ivory, warm grey, or yellow tint.
        • Do not apply plaster color variation on wall faces.
        • Use only thin edge shadows; do not darken broad wall surfaces.
        • Wall tops remain #111111 and must not bleed onto white wall faces.

        ════════════════════════════════════════════════════════════
        FLOOR + SHADOW CLEANUP LOCK:
        • Floor must appear smooth, clean, and neutral light grey.
        • Commercial and residential outputs must use the exact same clean SketchUp style.
        • Shadows must be visually absent from open floor areas.
        • Do not create broad grey shading across open floor areas.
        • Do not create cloudy shadow patches, scattered noise, grey stippling, salt-and-pepper dots, or dirty corner darkening.
        • Keep the result bright, clean, and SketchUp-like.

        ════════════════════════════════════════════════════════════
        FLOOR UNIFORMITY LOCK — MATCH APPROVED GOOD OUTPUTS
        ════════════════════════════════════════════════════════════
        • Floor must be one continuous clean #EEEEEE-style surface.
        • Do not create local bright islands, white clouds, grey clouds, or erased-looking patches.
        • Do not brighten the floor around dimension text, labels, furniture, beds, tables, chairs, sofas, counters, or fixtures.
        • Do not create halos around furniture or text.
        • Do not create grey dust around wall bases or object bases.
        • Large open floor areas must remain smooth and even.
        • Target result style: stable clean SketchUp output, smooth floor, no scattered shadow/noise.

        ════════════════════════════════════════════════════════════
        WALL TOP + FLOOR LOCK:
        • Every wall segment must show the near-black top cap with zero omissions.
        • This includes all small walls, partitions, enclosed-area walls, and narrow returns.
        • Floor must appear very light neutral grey and visually even.
        • Do not let the floor drift darker, dirtier, or more textured than the locked floor colour.

        ════════════════════════════════════════════════════════════
        WALL TOP SOURCE-OVERRIDE LOCK — CRITICAL
        ════════════════════════════════════════════════════════════
        • Do NOT inherit wall-top colour from the original floor plan.
        • Do NOT inherit missing/white/grey wall tops from IMAGE 1.
        • Regardless of what the source image shows, repaint EVERY wall-top face to #111111.
        • This applies to exterior walls, interior partitions, short walls, thin walls,
          enclosed-area walls, stair-adjacent walls, tiny returns, and narrow wall pieces.
        • If the source floor plan has no black wall caps, still create black wall-top caps.
        • If any wall segment has white/grey/missing top cap, the render is incorrect.
        • Wall-top rule is stronger than source-image appearance.

        ════════════════════════════════════════════════════════════
        BRIGHTNESS LOCK — MUST MATCH REFERENCE
        ════════════════════════════════════════════════════════════
        The final render must stay bright, clean, and high-key.
        • Keep surfaces bright but not overexposed.
        • Walls must appear neutral white with slight readable surface definition, never cream, beige, yellow, grey, or blown out.
        • Floor must appear smooth continuous neutral light grey, never pure white or dark concrete.
        • Window glass must appear consistently bright pale blue, not dull, white, or dark.
        • Interior corners must remain clean and bright.
        • Use very minimal shading only.
        • No white speckles, no blown-out patches, no cloudy white floor areas.
        • Avoid moody realism, dirty ambient occlusion, grey haze, or broad shadows.
        • Overall look must be closer to a clean SketchUp export than a realistic shaded render.

        ════════════════════════════════════════════════════════════
        CAMERA DEPTH LOCK — AVOID FLAT TOP-DOWN OUTPUT
        ════════════════════════════════════════════════════════════
        The camera must read as a true 3D isometric/axonometric SketchUp view.
        • Wall side faces must be clearly visible as vertical rectangles.
        • Show wall height on at least two exterior sides.
        • Do not output a near-vertical 2D plan with slight wall height.
        • If the floor dominates the image and wall faces look thin, regenerate with a lower isometric camera angle.

        ════════════════════════════════════════════════════════════
        REFERENCE THEME COLOUR LOCK — DO NOT DRIFT
        ════════════════════════════════════════════════════════════
        Match the LEFT reference image theme:
        • Wall faces must stay pure neutral white #FFFFFF.
        • Wall top caps must stay crisp black/graphite #111111.
        • Floor must stay very light neutral grey #EEEEEE, not warm grey, brown-grey, pure white, or dark concrete.
        • Window glass must be bright pale blue #D7F1F7, not white, grey, or green teal.
        • Window frames must be dark grey #4A4A4A.
        • Background must remain pure white #FFFFFF.
        • Overall look: clean SketchUp architectural render, not moody realistic render.
        • Do not add grey haze, beige cast, yellow cast, dirty ambient occlusion, dark shadows, or concrete mottling.

        ════════════════════════════════════════════════════════════
        TEXTURE / MATERIAL TARGET
        ════════════════════════════════════════════════════════════
        Use IMAGE 2 as the visual texture reference.
        Match its clean bright SketchUp-style architectural render feel:
        • clean bright wall surfaces with slight readable definition and no grey falloff
        • smooth continuous light grey floor with no speckles, no white scatter, and no cloudy patches
        • black wall caps with sharp edges
        • blue glass panels with transparency and reflection
        • realistic counters, wood, fabric, metal, and tile materials where present
        • only the faintest contact grounding, no dark shadows
        • keep colours from Style Spec, with clean controlled SketchUp brightness, not blown-out exposure

        ════════════════════════════════════════════════════════════
        ★ GLOBAL FURNITURE RULE — READ BEFORE EVERYTHING ELSE ★
        ════════════════════════════════════════════════════════════
        Furniture and objects are determined SOLELY by drawn symbols
        in the ORIGINAL FLOOR PLAN — never by room label names.

        A room called "BED ROOM" does NOT mean add a bed.
        A room called "KITCHEN" does NOT mean add counters or appliances.
        A room called "BAD" or "TOILET" does NOT mean add fixtures.
        A room called "Zimmer", "Hall", "Bar", "Auditorium" does NOT
        mean add any furniture, seats, or elements.

        The ONLY thing that authorises adding an object is:
        a drawn graphical symbol for that object existed in the
        original 2D floor plan. No drawn symbol = no object.

        ════════════════════════════════════════════════════════════
        FURNITURE POLICY
        ════════════════════════════════════════════════════════════
{furniture_mandate}

        ════════════════════════════════════════════════════════════
        DIMENSION ANNOTATIONS
        ════════════════════════════════════════════════════════════
        {measurement_mandate}

        MICRO-AREA MEASUREMENT LOCK:
        • Every separated enclosed/usable region must have one numeric L×W measurement.
        • Small spaces are not optional.
        • Do not skip tiny rooms, narrow corridors, service spaces, stair pockets,
          edge areas, entries, porches, balconies, or irregular niches.
        • If a dimension cannot fit inside, place it nearby with a short leader line.
        • Final output is incomplete if any usable/enclosed region has no numeric size.

        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        WALLS & SURFACES
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        • Apply colours from LOCKED STYLE SPEC as base/albedo colours.
        • Render surfaces as clean bright architectural materials, not dirty realistic fills.
        • Wall side faces must remain PURE NEUTRAL WHITE (#FFFFFF).
        • Do not turn wall faces grey, cream, beige, ivory, yellow, or warm off-white.
        • Only allow very faint edge shading for depth.
        • Large wall faces must stay visibly white and clean.
        • Keep EVERY wall position EXACTLY as in IMAGE 1.
        • Wall tops: preserve near-black colour family, thick and razor-sharp with crisp edges.

        COLOUR NEUTRALITY LOCK:
        • Walls must remain neutral white, not cream, beige, ivory, or yellow.
        • Floor must remain neutral light grey, not warm grey or brown-grey.
        • The overall render must feel clean white and cool-neutral, not warm-toned.

        EDGE LINEWORK — MANDATORY:
        - Every wall edge (top cap edge, side face edge, base edge) must carry
        a crisp 5px solid dark stroke (#111111).
        - Interior partition walls: 5px dark stroke on all visible edges.
        - Window cutout perimeter: 3px dark frame stroke.
        - Floor/wall junction lines: visible 1px dark baseline.
        - Wall-top caps must be continuous and complete across the entire building.
        - Do not break, fade, or skip the dark top cap on any wall segment.
        - Linework must remain clearly visible above all material shading.
        - No edge may be soft, blurred, dissolved into material, or missing.
        - Output should look like SketchUp with crisp profiles and edges turned on.
        - Glass/window boundaries: pale blue glass colour HARD-STOPS at frame edge —
        zero colour bleed or feathering onto adjacent wall or floor surface.
        - Furniture silhouettes: every piece has a sharp clean outline —
        no soft glow, no blurred boundary between object and floor.
        - Floor surface: sharp clean plane — no soft blending at wall bases
        beyond the allowed crisp 5px floor/wall edge stroke.
        - Wall top caps: razor-sharp upper and lower edges —
        near-black colour contained exactly within cap geometry.
        - SHARPNESS SELF-CHECK: zoom into any wall corner in your output.
        If edges look soft, blurred, or feathered → REGENERATE with
        harder edge treatment. Target: SketchUp screenshot sharpness.

        ╔══════════════════════════════════════════════════════════════╗
        ║  DOOR ARC LINES — FORBIDDEN IN FINAL RENDER                  ║
        ╠══════════════════════════════════════════════════════════════╣
        ║  If IMAGE 1 contains any curved arc lines on the floor       ║
        ║  near doorways — DO NOT reproduce them in your output.       ║
        ║  These are 2D drafting artifacts that must be erased.        ║
        ║                                                              ║
        ║  When rendering each doorway:                                ║
        ║    ✓ Show only the 3D door panel (slightly open, 20–35°)     ║
        ║    ✓ Floor beneath the doorway = clean, flat, arc-free       ║
        ║    ✗ No curved line on the floor at any door                 ║
        ║    ✗ No quarter-circle marking of any kind                   ║
        ║  This applies to EVERY door in every space type without      ║
        ║  exception.                                                  ║
        ╚══════════════════════════════════════════════════════════════╝

        WALL REALISM:
        • Wall tops are locked: keep exact thickness, shape, and near-black color.
        • Do not repaint, soften, distort, or break wall top caps.
        • Every wall segment must show the dark top cap.
        • No omissions are allowed on short walls, narrow walls, partitions,
          enclosed-area walls, step-adjacent walls, or tiny wall returns.
        • If any wall top is missing, the render is incorrect and must be regenerated.
        • Wall side faces must stay clean pure white.
        • Use only the minimum shading needed to show wall depth.
        • If a wall face looks beige, cream, grey, or yellow, regenerate.
        • No dark flat grey wall fill.
        • No dirty grunge, cracks, stains, or heavy texture.
        • Clean and high-key — like a bright professional SketchUp export.

        FLOORING:
        • Use floor colour as the base colour and keep it visually clean and even.
        • Render the floor as a simple very light neutral-grey architectural surface.
        • Use only extremely subtle shading.
        • Do NOT add concrete roughness, visible grain, or noisy material texture.
        • Do NOT add speckles, dust, scratches, stains, mottling, white scatter, patchy highlights, or cloudy shadow patches.
        • Keep the floor smooth and continuous across all rooms.
        • Do not render visible shadows on the floor; only a crisp 5px floor/wall edge stroke may exist.
        • Floor must be one continuous clean tone — no scattered dots, no grey stippling, no noisy shadow texture.
        • Keep the floor clean under and around all dimension text.
        • Dimension text is an annotation overlay and must remain crisp and unaffected.

        {lighting_environment}


    """
        + _ANTI_SHADOW_BLOB_FINAL_CHECK
    )
# ╚═══ END DEAD: STAGE_2B_APPLY_STYLE — reference-guided compositor ════════╝

# ╔═══ DEAD ════════════════════════════════════════════════════════════╗
# ║ STAGE_2B_APPLY_STYLE_NO_REF — universal compositor
# ║ source: backend/app/ai/rendering.py  lines 1313-1411
# ║ Reason: only reachable through RenderingService.generate_initial_render,
# ║         which is only called by ai_service.generate_3d / edit_render,
# ║         which are only called by services._execute_gen_3d_and_boq.
# ║         No route ever creates JobType.GEN_3D_AND_BOQ -> unreachable.
# ║ Evidence: generated_outputs/renders has 4 STAGE2_* files, newest
# ║         2026-06-12, vs 209 guided_render_* files up to 2026-07-28.
# ╚═══════════════════════════════════════════════════════════════════╝
    STAGE_2B_APPLY_STYLE_NO_REF = (
        _GEOMETRY_LOCK_HEADER
        + """
        [STAGE 2/2: SINGLE UNIVERSAL STYLE COMPOSITOR — No reference images]

        IMAGE 1 — 3D white-box skeleton (GEOMETRY LOCK — see header above).

        Space context:
          • Space type : {space_type}
          • Subtype    : {subtype_notes}
          • Count      : use IMAGE 1 visually; do not write any area names.
          • Style      : {style_recommendation}

        ════════════════════════════════════════════════════════════
        INITIAL USER PROMPT / INSTRUCTION ROUTER — MUST OBEY
        ════════════════════════════════════════════════════════════
{user_instruction_block}

        ════════════════════════════════════════════════════════════
        UNIVERSAL COLOUR THEME LOCK — SAME FOR ALL FLOOR PLANS
        ════════════════════════════════════════════════════════════
        • Use the exact same colour theme for every floor plan type.
        • Residential, commercial, cinema, office, restaurant, cafe, clinic, hotel,
          warehouse, mixed-use — all must use this same theme.
        • Wall tops: #111111.
        • Wall faces: #FAFAF7 by default, unless the user explicitly requests a different wall colour/material.
        • Floor: #E8E6E0 light warm-grey polished concrete / microcement by default, unless the user explicitly requests a different floor.
        • Window glass: #D7F1F7.
        • Window frames: #4A4A4A.
        • Background: #FFFFFF.
        • Do not create separate commercial colours or residential colours.

        ════════════════════════════════════════════════════════════
        WALL TOP SOURCE-OVERRIDE LOCK — CRITICAL
        ════════════════════════════════════════════════════════════
        • Do NOT inherit wall-top colour from the original floor plan.
        • Do NOT inherit missing/white/grey wall tops from IMAGE 1.
        • Regardless of what the source image shows, repaint EVERY wall-top face to #111111.
        • This applies to exterior walls, interior partitions, short walls, thin walls,
          enclosed-area walls, stair-adjacent walls, tiny returns, and narrow wall pieces.
        • If the source floor plan has no black wall caps, still create black wall-top caps.
        • If any wall segment has white/grey/missing top cap, the render is incorrect.
        • Wall-top rule is stronger than source-image appearance.

        ════════════════════════════════════════════════════════════
        ★ GLOBAL FURNITURE RULE — READ BEFORE EVERYTHING ELSE ★
        ════════════════════════════════════════════════════════════
        Furniture and objects are determined SOLELY by drawn symbols
        in the ORIGINAL FLOOR PLAN — never by room label names.

        A room called "BED ROOM" does NOT mean add a bed.
        A room called "KITCHEN" does NOT mean add counters or appliances.
        A room called "BAD" or "TOILET" does NOT mean add fixtures.
        A room called "Zimmer", "Hall", "Bar", "Auditorium" does NOT
        mean add any furniture, seats, or elements.

        The ONLY thing that authorises adding an object is:
        a drawn graphical symbol for that object existed in the
        original 2D floor plan. No drawn symbol = no object.

        EXCEPTION — EXPLICIT INITIAL USER INSTRUCTION:
        If the INITIAL USER PROMPT above explicitly asks to add furniture, fixtures,
        objects, or decor, then add ONLY those requested items. Do not infer extra
        objects from room names. Do not change floors, walls, toilets, windows,
        colours, labels, camera, or layout while adding those requested items.

{furniture_mandate}

        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        DIMENSION ANNOTATIONS
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        {measurement_mandate}

        MICRO-AREA MEASUREMENT LOCK:
        • Every separated enclosed/usable region must have one numeric L×W measurement.
        • Small spaces are not optional.
        • Do not skip tiny rooms, narrow corridors, service spaces, stair pockets,
          edge areas, entries, porches, balconies, or irregular niches.
        • If a dimension cannot fit inside, place it nearby with a short leader line.
        • Final output is incomplete if any usable/enclosed region has no numeric size.

        ╔══════════════════════════════════════════════════════════════╗
        ║  VISUAL STYLE TARGET                                         ║
        ╚══════════════════════════════════════════════════════════════╝
        {style_descriptor}

        THEME CONSISTENCY RULE:
        • The style descriptor is mandatory, not optional.
        • Do not create a different palette based on floor plan type.
        • Do not let commercial/cinema plans become darker, greyer, warmer, or more realistic.
        • Use the same clean SketchUp theme as residential outputs.
        • Wall-top #111111, wall #FAFAF7, floor #E8E6E0 microcement, windows #D7F1F7, frames #4A4A4A by default.

{lighting_environment}


    """
        + _ANTI_SHADOW_BLOB_FINAL_CHECK
    )
# ╚═══ END DEAD: STAGE_2B_APPLY_STYLE_NO_REF — universal compositor ════════╝

# ╔═══ DEAD ════════════════════════════════════════════════════════════╗
# ║ RESIDENTIAL_SKETCHUP_STYLE
# ║ source: backend/app/ai/rendering.py  lines 1417-1445
# ║ Reason: only reaches a prompt through STYLE_PRESETS ->
# ║         apply_universal_style {style_descriptor} (dead).
# ╚═══════════════════════════════════════════════════════════════════╝
    RESIDENTIAL_SKETCHUP_STYLE = """
        VISUAL STYLE — UNIVERSAL CLEAN SKETCHUP STYLE:

        WALL TOPS    : #111111  — crisp near-black cap on every wall segment.
        WALL FACES   : #FAFAF7  — clean matte off-white / neutral architectural white, no cream/beige/yellow cast.
        FLOORS       : #E8E6E0  — light warm-grey polished concrete / microcement, subtle cloudy low-contrast texture, matte/satin finish, no tile seams.
        WINDOWS      : #D7F1F7  — bright pale blue transparent glass.
        Frame: #4A4A4A dark neutral grey aluminium, crisp thin profile.
        BATHROOM WALLS:#FFFFFF  — same neutral white as all other walls.
        BACKGROUND   : #FFFFFF  — pure white.

        SHARPNESS    : SketchUp-style hard edges throughout. Every wall, window
           frame, furniture piece, and floor boundary = razor-sharp.
           No soft rendering, no blurred edges, no glow effects.
           Glass pale blue colour MUST NOT bleed onto floor or walls.
           Output must look like a crisp SketchUp model screenshot.

        Furniture: walnut #A07840 wardrobes, grey #808080 sofas,
        white #FFFFFF bed frames, grey #D8D8D8 bedding, dark #4A3728 tables.
        Grey #D0D0D0 kitchen cabinets. Dark grey #606060 kitchen counter.

        LIGHTING: 6500K bright neutral white studio light, high exposure, minimal shading, no warm tint, no visible shadow.
        Every surface evenly lit. Floor stays near its light warm-grey microcement base and never becomes pure white.
        Shadow rule: NO visible shadow fields, NO shadow clouds, NO scattered shadow noise.
        Only a mathematically thin wall-base contact line may exist, and it must not spread onto open floor.
        No shadow pools. No dark corners. No moody atmosphere. No visible AO.
        No white speckles, no cloudy white floor patches, no grey stippling, no blown-out wall/floor areas.
        No beige cast, cream tint, yellow tint, or warm brown colour grading.
    """
# ╚═══ END DEAD: RESIDENTIAL_SKETCHUP_STYLE ════════════════════════════════╝

# ╔═══ DEAD ════════════════════════════════════════════════════════════╗
# ║ STYLE_PRESETS
# ║ source: backend/app/ai/rendering.py  lines 1447-1450
# ║ Reason: same as RESIDENTIAL_SKETCHUP_STYLE.
# ╚═══════════════════════════════════════════════════════════════════╝
    STYLE_PRESETS = {
        "modern_residential": RESIDENTIAL_SKETCHUP_STYLE,
        "retail_commercial": RESIDENTIAL_SKETCHUP_STYLE,
    }
# ╚═══ END DEAD: STYLE_PRESETS ═════════════════════════════════════════════╝

# ╔═══ LIVE ════════════════════════════════════════════════════════════╗
# ║ STAGE_EDIT_AREA — area edit
# ║ source: backend/app/ai/rendering.py  lines 1456-1496
# ║ Path: routes GEN_3D job -> services._execute_gen_3d -> ai_service
# ║       -> RenderingService.edit_by_instruction / edit_area.
# ╚═══════════════════════════════════════════════════════════════════╝
    STAGE_EDIT_AREA = """
        [TARGETED AREA EDIT — STRICT 3D-ONLY LOCAL EDIT]

        ★★★ EDIT SOURCE LOCK — CRITICAL ★★★
        You are editing ONLY the provided latest/selected 3D render image.
        The original 2D floor plan is NOT provided and must NOT influence this edit.
        Do NOT restore, re-read, infer, or recreate anything from any original 2D floor plan.
        Do NOT add old room labels, function labels, title blocks, plan text, legends, or 2D annotations.

        TWO IMAGES ONLY:
          IMAGE 1 — CLEAN CURRENT 3D RENDER (base — no guide marks).
          IMAGE 2 — CYAN REGION GUIDE derived from IMAGE 1 (edit zone only — do NOT reproduce in output).

        USER INSTRUCTION: {instruction}

        {strict_edit_scope_lock}

        ════════════════════════════════════════════════
        AREA EDIT TASK
        ════════════════════════════════════════════════
        1. Use IMAGE 1 as the only architectural truth.
        2. Identify edit area from IMAGE 2 cyan overlay.
        3. Apply USER INSTRUCTION ONLY inside the cyan identified area.
        4. OUTSIDE area = pixel-perfect copy of IMAGE 1. Zero changes.
        5. Output: zero cyan guide marks, zero annotation artifacts.

        HARD PRESERVATION LOCK:
        • Same camera angle, crop, scale, perspective, and lighting as IMAGE 1.
        • Same walls, wall positions, partitions, openings, windows, doors, stairs, dimensions, and linework.
        • Same floor/wall theme unless the user explicitly asks to change floor/walls.
        • Do NOT change toilet/bathroom colors, washroom wall colors, windows, wall colors, floor material, labels, dimensions, or unrelated rooms.
        • Do NOT add room names, function labels, legend text, title text, or any new text.
        • Do NOT move the edit into a wrong room or wrong file/image. The cyan region from IMAGE 2 is the only target zone.

        WHAT YOU CAN CHANGE:
        • Only what the user requested.
        • Only inside traced/cyan area.
        • Only as much as needed for the requested edit.

        OUTPUT: clean professional render. Zero region-guide marks. No labels. No unrelated changes.
    """
# ╚═══ END LIVE: STAGE_EDIT_AREA — area edit ═══════════════════════════════╝

# ╔═══ LIVE ════════════════════════════════════════════════════════════╗
# ║ STAGE_CHAT_EDIT_WITH_HISTORY — chat / instruction edit
# ║ source: backend/app/ai/rendering.py  lines 1502-1536
# ║ Path: routes GEN_3D job -> services._execute_gen_3d -> ai_service
# ║       -> RenderingService.edit_by_instruction / edit_area.
# ╚═══════════════════════════════════════════════════════════════════╝
    STAGE_CHAT_EDIT_WITH_HISTORY = """
        [CHAT-BASED INSTRUCTION EDIT — STRICT 3D-ONLY EDIT]

        ★★★ EDIT SOURCE LOCK — CRITICAL ★★★
        You are editing ONLY IMAGE 1, the latest/selected 3D render.
        The original 2D floor plan is NOT provided and must NOT influence this edit.
        Do NOT restore, re-read, infer, or recreate anything from the original 2D floor plan.
        Do NOT add old room labels, function labels, title blocks, legends, plan text, or 2D annotations.

        IMAGE 1 — Current/latest 3D render (the ONLY editing base and architectural truth).

        SESSION CONTEXT (already applied — do NOT undo):
        {edit_history}

        CURRENT USER INSTRUCTION:
        {instruction}

        {strict_edit_scope_lock}

        ════════════════════════════════════════════════
        CHAT EDIT TASK
        ════════════════════════════════════════════════
        • IMAGE 1 already contains all previous successful changes.
        • Apply ONLY the current user instruction on top of IMAGE 1.
        • Do NOT undo previous edits unless the current instruction explicitly asks.
        • Do NOT add changes not asked for.
        • Current instruction beats prior history only if directly conflicting.
        • If the user asks to add furniture/functions/objects, add only those requested objects.
        • Do NOT change toilet/bathroom/washroom wall colors, floor color/material, wall theme, windows, lighting, camera, dimensions, or unrelated rooms unless explicitly requested.
        • Preserve existing numeric dimensions if visible, but do not create any new room/function labels.
        • No labels, no room names, no title text, no legend text, no 2D floor-plan annotations.
        • Do not place the requested change in the wrong image/file; edit IMAGE 1 only.

        OUTPUT: Clean professional 3D render. Same camera angle as IMAGE 1. No labels. No unrelated changes.
    """
# ╚═══ END LIVE: STAGE_CHAT_EDIT_WITH_HISTORY — chat / instruction edit ════╝

# ╔═══ DEAD ════════════════════════════════════════════════════════════╗
# ║ STAGE_CHAT_EDIT — chat edit without history
# ║ source: backend/app/ai/rendering.py  lines 1538-1555
# ║ Reason: zero references. edit_by_instruction always uses the
# ║         _WITH_HISTORY variant.
# ╚═══════════════════════════════════════════════════════════════════╝
    STAGE_CHAT_EDIT = """
        [CHAT-BASED INSTRUCTION EDIT — STRICT 3D-ONLY]

        ★★★ EDIT SOURCE LOCK ★★★
        Edit ONLY IMAGE 1, the current/latest 3D render.
        The original 2D floor plan is NOT provided and must NOT be used.
        Do NOT add old labels, room names, function labels, title blocks, legends, or 2D annotations.

        IMAGE 1 — Current/latest 3D render.

        USER INSTRUCTION: {instruction}

        {strict_edit_scope_lock}

        Apply ONLY the instruction. Everything else must remain identical to IMAGE 1.
        Keep camera angle, dimensions, walls, windows, toilet/bathroom wall colors, floor/wall theme, and unrelated rooms unchanged.
        Output clean professional architectural render with no labels and no unrelated changes.
    """
# ╚═══ END DEAD: STAGE_CHAT_EDIT — chat edit without history ═══════════════╝

# ╔═══ DEAD ════════════════════════════════════════════════════════════╗
# ║ REFERENCE_CATEGORY_MAP
# ║ source: backend/app/ai/rendering.py  lines 1557-1570
# ║ Reason: zero references. _discover_references_by_category returns []
# ║         unconditionally - reference images are disabled by design.
# ╚═══════════════════════════════════════════════════════════════════╝
    REFERENCE_CATEGORY_MAP = {
        "residential_house":     "residential",
        "residential_apartment": "residential",
        "office":                "commercial",
        "retail_shop":           "commercial",
        "restaurant":            "commercial",
        "cafe":                  "commercial",
        "cinema":                "commercial",
        "hotel":                 "commercial",
        "clinic":                "commercial",
        "gym":                   "commercial",
        "warehouse":             "commercial",
        "mixed_use":             "commercial",
    }
# ╚═══ END DEAD: REFERENCE_CATEGORY_MAP ════════════════════════════════════╝


# The two blocks below are class attributes of RenderingService in the
# original file. `class RenderingServicePrompts:` is an added wrapper line.
class RenderingServicePrompts:

    # ╔═══ LIVE ════════════════════════════════════════════════════════════╗
    # ║ _ISOMETRIC_CAMERA_PROMPT
    # ║ source: backend/app/ai/rendering.py  lines 3611-3759
    # ║ Path: STEP2_GEN_ISOMETRIC job -> generate_angled_view ->
    # ║       generate_isometric_from_image. Serves BOTH UI options
    # ║       (isometric + birds_eye). 24 ISOMETRIC_* renders, newest 2026-07-25.
    # ║ Note: a caller-supplied prompt is deliberately IGNORED here.
    # ╚═══════════════════════════════════════════════════════════════════╝
    # One server-controlled prompt is used for both the "isometric" and
    # "birds_eye" UI choices.  Keeping it here (rather than accepting a short
    # frontend replacement prompt) prevents the camera and fidelity rules from
    # drifting between entry points.
    _ISOMETRIC_CAMERA_PROMPT = """
Perform a strict camera-angle-only edit of the supplied architectural 3D floor-plan image.

The input image is the sole and absolute source of truth. Preserve the exact same 3D model, exact same floor plan, exact same room layout, exact same walls, exact same furniture, exact same materials, exact same labels, and exact same rendering style.

REQUIRED VIEW TRANSFORMATION

Change the camera to a low front perspective / isometric-perspective style view.

The view should feel like a camera is floating in front of the floor plan, slightly above it, and looking inward across the plan from the bottom of the screen toward the top of the screen.

Important orientation rule:
Ignore the architectural “front/back” of the building itself.
Use screen orientation only:

bottom of the image = front / near side
top of the image = back / far side

The camera must be positioned near the bottom-center of the image, looking toward the top-center.

CAMERA / PERSPECTIVE TARGET

Create a view with these characteristics:

camera floating in front of the bottom edge of the floor plan
camera lowered significantly
camera slightly above the floor level, not high overhead
viewing direction from bottom of screen toward top of screen
gentle downward tilt into the interior
clear perspective projection
the front / bottom walls must appear larger, taller, and more dominant
objects and walls should visibly recede into depth
the back / top area should appear smaller as it goes farther away
strong sense of front-to-back perspective depth
much less top-down appearance
not an exterior street-level eye view, but a floating low architectural perspective
VISUAL GOAL

The result should look like:

the camera is hovering in front of the plan
the bottom/front edge is closest to the viewer
the front walls are clearly visible in height
the plan recedes naturally toward the top
the nearer foreground appears larger
the far background appears smaller
there is a proper low-angle isometric-perspective / architectural perspective feel

This is not a top-down axonometric view.
This is not a flat orthographic isometric.
This should be a perspective view with visible depth compression from front to back.

OCCLUSION RULE

It is acceptable, and preferred, if the new lower front perspective causes:

some top/back elements to become partially hidden
some rear furniture or wall portions to be less visible
some upper areas to be obscured by nearer walls

Do not try to keep every part equally visible from above.

Prioritize the correct low front perspective over maximum top-down visibility.

ABSOLUTE PRESERVATION

Preserve exactly:

building footprint and proportions
room layout and room dimensions
wall positions, wall heights, wall thicknesses, and openings
doors, windows, staircase, balcony, and railings
furniture, fixtures, appliances, plants, and decorations
object count, scale, orientation, and placement
flooring, wall finishes, wood textures, and all material textures
colours, lighting character, shadows, and rendering style
dimension lines, arrows, labels, numbers, units, and typography

Do not add, remove, replace, redesign, restyle, resize, rotate, mirror, simplify, relocate, or reinterpret anything.

STRICT NON-INVENTION RULE

Do not invent any new architectural or decorative content.

Do not add:

new walls
new furniture
new decorations
new railings
new textures
new materials
new labels
new measurements
new exterior elements
new hidden surfaces
new object details not visible in the source

If the lower perspective reveals areas that were not clearly visible before, do not creatively complete them.

Only use what is supported by the source image.
Natural occlusion is acceptable and preferred over invention.

ONLY ALLOWED CHANGE

The only allowed modification is the viewpoint:

move the camera to the bottom/front side of the screen
lower the camera significantly
make the view more frontal from the bottom edge
apply a clear perspective projection
show more wall height in the foreground
make the scene recede toward the top of the image
keep the scene itself completely unchanged
WHAT MUST NOT HAPPEN

Do not:

regenerate the architecture
redesign the floor plan
change room sizes
change wall geometry
change furniture positions
improve or beautify the design
invent plausible missing details
change colours or materials
change lighting setup
sharpen, stylize, or enhance the image
keep a top-down isometric look
use the building’s own “front” orientation instead of the screen bottom-to-top orientation
FINAL RESULT

The output must look like the exact same architectural floor-plan render, but viewed from a lower floating front perspective, where:

the bottom of the screen is the near/front side
the top of the screen is the far/back side
the front walls are larger and taller
the scene gets smaller toward the top
there is a clear architectural perspective depth
some rear/top elements may be partially hidden

Camera change only. Perspective view from screen-bottom toward screen-top. No redesign. No invention. No added details.
"""

    _ISOMETRIC_VIEW_TYPES = frozenset({"isometric", "birds_eye"})
    # ╚═══ END LIVE: _ISOMETRIC_CAMERA_PROMPT ══════════════════════════════════╝

    # ╔═══ UI-UNREACHABLE ══════════════════════════════════════════════════╗
    # ║ _ANGLE_PROMPTS
    # ║ source: backend/app/ai/rendering.py  lines 3882-3929
    # ║ 'isometric' and 'birds_eye' are None -> they route to
    # ║ _ISOMETRIC_CAMERA_PROMPT above (LIVE).
    # ║ front_elevation / side_elevation / corner_perspective are never
    # ║ reached: frontend VIEW_ANGLES (Step2.jsx:120) only offers the first
    # ║ two. Hittable only by POSTing view_type directly to the API.
    # ╚═══════════════════════════════════════════════════════════════════╝
    # Per-view-type prompt library
    _ANGLE_PROMPTS = {
        "isometric": None,  # None → generate_isometric_from_image uses its own built-in prompt
        # Product terminology treats bird's-eye as the same elevated oblique
        # isometric camera, never as a flat 90-degree overhead plan.
        "birds_eye": None,

        "front_elevation": (
            "Recreate this 3D render as a flat FRONT ELEVATION architectural view.\n\n"
            "Camera: placed directly in front of the main façade, perfectly orthographic (no perspective distortion).\n"
            "The image should look like a technical elevation drawing rendered in SketchUp style.\n\n"
            "WHAT MUST STAY IDENTICAL:\n"
            "- Wall colours, materials, and surface finishes\n"
            "- Window and door positions on the front face\n"
            "- SketchUp crisp black edge lines\n"
            "- Matte white/off-white walls\n\n"
            "WHAT CHANGES: Viewing angle only — flat orthographic front face, no 3D depth visible on sides.\n"
            "Clean white background. The result should look like the front face of the building drawn straight-on."
        ),

        "side_elevation": (
            "Recreate this 3D render as a flat SIDE ELEVATION architectural view.\n\n"
            "Camera: placed directly at the left (or right) side wall, perfectly orthographic (no perspective distortion).\n"
            "The image should look like a technical side-elevation drawing rendered in SketchUp style.\n\n"
            "WHAT MUST STAY IDENTICAL:\n"
            "- Wall colours, materials, and surface finishes\n"
            "- Window and door positions on the side face\n"
            "- SketchUp crisp black edge lines\n"
            "- Matte white/off-white walls\n\n"
            "WHAT CHANGES: Viewing angle only — flat orthographic side face, camera looks directly at the side wall.\n"
            "Clean white background."
        ),

        "corner_perspective": (
            "Recreate this 3D render from a CORNER PERSPECTIVE — a dramatic 3/4 angle looking INTO the space.\n\n"
            "Camera: positioned at one corner, elevated 30–40° above horizontal, aimed diagonally inward.\n"
            "Two walls and most of the floor are clearly visible. The viewer feels like standing at the corner and looking across.\n\n"
            "WHAT MUST STAY IDENTICAL:\n"
            "- Every colour, material, and surface finish — copy exactly\n"
            "- Every room's floor colour and texture\n"
            "- Every wall colour and thickness\n"
            "- Every window, door, and opening — same teal/cyan accent\n"
            "- All furniture and fixtures visible in the source\n"
            "- SketchUp-style crisp black outlines and matte surfaces\n\n"
            "WHAT CHANGES: Camera angle only — from current view → corner 3/4 perspective.\n"
            "Clean white background. No text, labels, or annotations."
        ),
    }
    # ╚═══ END UI-UNREACHABLE: _ANGLE_PROMPTS ══════════════════════════════════╝

