# Runtime prompt builders used by the rendering pipeline.
#
# ANNOTATED VIEW — prompt text is byte-identical to the source; the only
# added lines are the LIVE / DEAD marker banners that wrap each prompt, plus
# this header and imports. Pristine un-annotated originals: ../llm_calls/
#
#   LIVE            = reachable and actually running in production today
#   DEAD            = defined but unreachable from any route/job in the app
#   UI-UNREACHABLE  = reachable via direct API call, but no UI path reaches it
#
# Source of truth: backend/app/ai/rendering.py (methods of RenderingService)
from typing import Any, Dict, List, Optional

# `Prompts` lives in prompts_rendering_stage.py (same folder).


# `class RenderingServicePromptBuilders:` is an added wrapper line so the
# method bodies keep their original indentation.
class RenderingServicePromptBuilders:

    # ╔═══ LIVE ════════════════════════════════════════════════════════════╗
    # ║ _strict_edit_scope_lock()
    # ║ source: backend/app/ai/rendering.py  lines 1858-1860
    # ║ Called by edit_by_instruction and edit_area (both live).
    # ╚═══════════════════════════════════════════════════════════════════╝
    def _strict_edit_scope_lock(self, instruction: Optional[str]) -> str:
        safe_instruction = (instruction or "").strip() or "No extra change requested."
        return Prompts._STRICT_EDIT_SCOPE_LOCK.format(instruction=safe_instruction)
    # ╚═══ END LIVE: _strict_edit_scope_lock() ═════════════════════════════════╝

    # ╔═══ DEAD ════════════════════════════════════════════════════════════╗
    # ║ _build_furniture_mandate()
    # ║ source: backend/app/ai/rendering.py  lines 2567-2602
    # ║ Reason: only called by apply_universal_style (dead).
    # ╚═══════════════════════════════════════════════════════════════════╝
    def _build_furniture_mandate(self, analysis: Dict) -> str:
        coverage        = analysis.get("furniture_coverage", "none")
        furniture_items = analysis.get("furniture_items", [])
        furniture_by_room: Dict = analysis.get("furniture_by_room", {})

        if coverage not in ("full", "partial", "none"):
            coverage = "partial" if analysis.get("has_furniture", False) else "none"

        if coverage == "none":
            return Prompts._ZERO_FURNITURE_MANDATE

        if coverage == "full":
            items_str = ", ".join(furniture_items) if furniture_items else "see floor plan symbols"
            return Prompts._FURNITURE_MIRRORING_MANDATE.format(furniture_list=items_str)

        # Partial — room-by-room explicit table
        all_rooms:      List[str] = analysis.get("key_rooms", [])
        furnished_names           = list(furniture_by_room.keys())
        empty_names               = [r for r in all_rooms if r not in furnished_names]

        if not furnished_names:
            return Prompts._ZERO_FURNITURE_MANDATE

        # Build a clear room-by-room table
        room_lines = []
        for room, items in furniture_by_room.items():
            room_short  = f"{len(room_lines) + 1:02d}"
            action_str  = f"FURNISHED — replace slabs only where grey slabs exist"[:60]
            room_lines.append(f"║ {room_short:<18} ║ {action_str:<49}║\n")
        for room in empty_names:
            room_short = f"{len(room_lines) + 1:02d}"
            room_lines.append(f"║ {room_short:<18} ║ {'EMPTY — ZERO objects on floor':<49}║\n")

        room_table = "".join(room_lines) if room_lines else "║ 01                 ║ Follow grey slabs only                          ║\n"

        return Prompts._PARTIAL_FURNITURE_MANDATE.format(room_table=room_table)
    # ╚═══ END DEAD: _build_furniture_mandate() ════════════════════════════════╝

    # ╔═══ DEAD ════════════════════════════════════════════════════════════╗
    # ║ _build_measurement_mandate() — 276 lines
    # ║ source: backend/app/ai/rendering.py  lines 2604-2879
    # ║ Reason: only called by apply_universal_style (dead).
    # ║ The live guided pipeline gets dimensions from _DIMENSION_LABEL_BLOCK
    # ║ in prompts.py instead.
    # ╚═══════════════════════════════════════════════════════════════════╝
    def _build_measurement_mandate(self, analysis: Dict) -> str:
        """
        Build the dimension-only annotation rules.

        v3 requirement implemented here:
        - Preserve any numeric size/dimension already written in the source plan exactly.
        - For every enclosed/usable area that has no written size, estimate L×W from the
          plan scale/proportions and mark it with (est.).
        - Never render room/function names; visible text must be numeric dimensions only.
        """
        coverage   = analysis.get("dimension_coverage", "none")
        unit_sys   = analysis.get("unit_system",         "metric")
        dominant_u = analysis.get("dominant_unit",        "m")
        wall_h     = analysis.get("wall_height_estimate", "2.80m")
        wall_ext   = analysis.get("wall_thickness_ext",   "200mm")
        wall_int   = analysis.get("wall_thickness_int",   "100mm")
        door_w     = analysis.get("door_width_typical",   "0.90m")
        win_w      = analysis.get("window_width_typical", "1.20m")
        space_type = analysis.get("space_type",           "residential_apartment")

        key_rooms = analysis.get("key_rooms", []) or []
        all_areas = analysis.get("all_enclosed_or_usable_areas", []) or []
        areas_with_dimensions = analysis.get("areas_with_dimensions", []) or []
        areas_missing_dimensions = analysis.get("areas_missing_dimensions", []) or []

        if coverage not in ("full", "partial", "none"):
            coverage = "partial" if analysis.get("has_dimensions", False) else "none"
        if unit_sys in ("unknown", ""):
            unit_sys = "metric"
        if dominant_u in ("unknown", ""):
            dominant_u = "m"

        unit_note = (
            f"UNIT SYSTEM: {unit_sys.upper()} — use {dominant_u} for ALL new estimated values. "
            "NEVER mix units or leave a value blank."
        )

        # Internal estimation hints only. These words are for sizing logic only;
        # they must NEVER be rendered as visible labels in the output image.
        _METRIC_RESIDENTIAL = {
            "bedroom": "3.50 × 3.00 m", "schlafzimmer": "3.50 × 3.00 m",
            "zimmer": "4.00 × 3.50 m", "living": "5.00 × 4.00 m",
            "wohnzimmer": "5.00 × 4.00 m", "hall": "4.50 × 3.50 m",
            "lobby": "4.00 × 3.00 m", "kitchen": "3.00 × 2.50 m", "küche": "3.00 × 2.50 m",
            "bathroom": "2.50 × 1.80 m", "bad": "2.50 × 1.80 m",
            "toilet": "1.80 × 1.20 m", "balcony": "3.00 × 1.50 m",
            "balkon": "3.00 × 1.50 m", "corridor": "2.50 × 1.20 m", "passage": "2.50 × 1.20 m",
            "flur": "2.50 × 1.20 m", "stair": "3.00 × 2.20 m", "stairs": "3.00 × 2.20 m",
            "landing": "2.20 × 1.80 m", "porch": "3.00 × 2.00 m", "car porch": "5.50 × 3.00 m",
            "carporch": "5.50 × 3.00 m", "car park": "5.50 × 3.00 m", "garage": "5.50 × 3.00 m",
            "terrace": "3.50 × 2.00 m", "lawn": "4.00 × 3.00 m", "utility": "2.00 × 1.50 m",
            "store": "2.00 × 1.50 m", "wardrobe": "2.00 × 0.80 m", "default": "3.00 × 2.50 m",
        }
        _IMPERIAL_RESIDENTIAL = {
            "bedroom": "12'-0\" × 10'-0\"", "schlafzimmer": "12'-0\" × 10'-0\"",
            "zimmer": "13'-0\" × 11'-0\"", "living": "16'-0\" × 13'-0\"",
            "wohnzimmer": "16'-0\" × 13'-0\"", "hall": "15'-0\" × 12'-0\"",
            "lobby": "13'-0\" × 10'-0\"", "kitchen": "10'-0\" × 8'-0\"", "küche": "10'-0\" × 8'-0\"",
            "bathroom": "8'-0\" × 6'-0\"", "bad": "8'-0\" × 6'-0\"",
            "toilet": "6'-0\" × 4'-0\"", "balcony": "10'-0\" × 5'-0\"",
            "balkon": "10'-0\" × 5'-0\"", "corridor": "8'-0\" × 4'-0\"", "passage": "8'-0\" × 4'-0\"",
            "flur": "8'-0\" × 4'-0\"", "stair": "10'-0\" × 7'-0\"", "stairs": "10'-0\" × 7'-0\"",
            "landing": "7'-0\" × 6'-0\"", "porch": "10'-0\" × 7'-0\"", "car porch": "18'-0\" × 10'-0\"",
            "carporch": "18'-0\" × 10'-0\"", "car park": "18'-0\" × 10'-0\"", "garage": "18'-0\" × 10'-0\"",
            "terrace": "12'-0\" × 7'-0\"", "lawn": "13'-0\" × 10'-0\"", "utility": "7'-0\" × 5'-0\"",
            "store": "7'-0\" × 5'-0\"", "wardrobe": "6'-0\" × 3'-0\"", "default": "10'-0\" × 8'-0\"",
        }
        _COMMERCIAL = {
            "bar": "15.0 × 12.0 m", "auditorium": "20.0 × 18.0 m",
            "lobby": "10.0 × 8.0 m", "corridor": "8.0 × 2.5 m", "passage": "8.0 × 2.5 m",
            "unit": "6.0 × 5.0 m", "office": "5.0 × 4.0 m", "shop": "6.0 × 5.0 m",
            "reception": "6.0 × 4.0 m", "toilet": "2.0 × 1.5 m", "bathroom": "2.5 × 1.8 m",
            "stair": "4.0 × 3.0 m", "stairs": "4.0 × 3.0 m", "landing": "3.0 × 2.0 m",
            "balcony": "4.0 × 2.0 m", "terrace": "5.0 × 3.0 m", "porch": "4.0 × 3.0 m",
            "car porch": "5.5 × 3.0 m", "carporch": "5.5 × 3.0 m", "car park": "5.5 × 3.0 m",
            "default": "8.0 × 6.0 m",
        }

        is_commercial = space_type in (
            "office", "retail_shop", "restaurant", "cafe",
            "cinema", "hotel", "clinic", "gym", "warehouse", "mixed_use",
        )
        is_imperial = unit_sys == "imperial"

        if is_commercial:
            dim_hints = _COMMERCIAL
        elif is_imperial:
            dim_hints = _IMPERIAL_RESIDENTIAL
        else:
            dim_hints = _METRIC_RESIDENTIAL

        def _hint_for_area(area: Any) -> str:
            area_lower = str(area).lower()
            matched_dim = dim_hints.get("default", "3.0 × 2.5 m")
            # Longest key first so "car porch" beats "porch".
            for key in sorted(dim_hints, key=len, reverse=True):
                if key != "default" and key in area_lower:
                    matched_dim = dim_hints[key]
                    break
            return matched_dim

        # Build a compact internal coverage table. Names in this table are explicitly
        # logic-only and must never be visible in the generated image.
        area_lines = []
        if not all_areas:
            area_coverage_block = (
                "    Analyzer did not return area list. The renderer MUST visually count every "
                "separated enclosed/usable region in IMAGE 1 and place one numeric L×W tag in each."
            )
        else:
            normalized_with = {str(x).strip().lower() for x in areas_with_dimensions}
            normalized_missing = {str(x).strip().lower() for x in areas_missing_dimensions}
            for idx, area in enumerate(all_areas[:24], start=1):
                area_name = str(area)
                low = area_name.strip().lower()
                if low in normalized_with:
                    action = "COPY EXISTING NUMERIC DIMENSION VERBATIM"
                elif low in normalized_missing or coverage in ("partial", "none"):
                    action = f"ADD NUMERIC L×W ESTIMATE ONLY, e.g. {_hint_for_area(area_name)} (est.) if no numeric size is visible"
                else:
                    action = "COPY if visible; otherwise ADD ESTIMATE (est.)"
                area_lines.append(f"    {idx}: {action}")
            area_coverage_block = "\n".join(area_lines)

        missing_lines = []
        for idx, area in enumerate((areas_missing_dimensions or [])[:20], start=1):
            missing_lines.append(f"    {idx}: add {_hint_for_area(area)} (est.) only; render no name")
        missing_block = "\n".join(missing_lines) if missing_lines else (
            "    Detect missing-size zones visually from separated floor regions only. "
            "Add L×W (est.) to each if no numeric size exists. Render numbers only."
        )

        if coverage == "full":
            sourcing_note = (
                "SOURCING: FULL — copy ALL existing numeric dimension values VERBATIM from IMAGE 1.\n"
                "Still perform a coverage pass: if any enclosed/usable area has no numeric L×W tag, "
                "add an estimated value and mark (est.). Do NOT copy room/function names."
            )
        elif coverage == "partial":
            sourcing_note = (
                "SOURCING: PARTIAL — copy existing numeric dimension labels exactly from IMAGE 1 floor plan.\n"
                "For every area without a numeric dimension, estimate its L×W from plan scale/proportions "
                "and mark (est.). Do NOT copy room/function names."
            )
        else:
            sourcing_note = (
                "SOURCING: NONE — no usable numeric dimension labels exist in the floor plan.\n"
                "Estimate every enclosed/usable area from proportions and mark every L×W value (est.).\n"
                "YOU MUST STILL WRITE ACTUAL NUMBERS — do not draw blank tick marks."
            )

        mandate = (
            "\n"
            + sourcing_note + "\n"
            + unit_note + "\n"
            + """
╔══════════════════════════════════════════════════════════════════╗
║  DIMENSION-ONLY MANDATE — ABSOLUTE ZERO LABELS                  ║
╠══════════════════════════════════════════════════════════════════╣
║  Visible text may contain ONLY:                                 ║
║    ✓ digits 0–9                                                 ║
║    ✓ decimal points                                             ║
║    ✓ feet/inch marks: ' and "                                   ║
║    ✓ unit symbols: m, mm, ft, in                                ║
║    ✓ dimension separators: ×, x, -, =                           ║
║    ✓ parentheses only for (est.)                                ║
║                                                                  ║
║  Visible text may NOT contain any room/space/function word.      ║
║                                                                  ║
║  FORBIDDEN visible words/tokens:                                 ║
║    ROOM, SMALL ROOM, AREA, BAR, BAR AREA, SERVICE, SERVICE AREA, ║
║    CORRIDOR, STAIRS, STAIR, LOBBY, AUDITORIUM, HALL, LOUNGE,     ║
║    BED, BEDROOM, BED ROOM, KITCHEN, TOILET, BATHROOM, BATH,      ║
║    OFFICE, STORE, BALCONY, PORCH, TERRACE, LAWN, UTILITY,        ║
║    TOTAL, OVERALL, WIDTH, DEPTH, HEIGHT, FLOOR, PLAN, LABEL.     ║
║                                                                  ║
║  Correct examples:                                               ║
║    ✓ 9'-0" × 13'-0"                                             ║
║    ✓ 10'-0" × 7'-0" (est.)                                      ║
║    ✓ 25.00 m                                                    ║
║    ✓ 3'-0" × 4'-0" (est.)                                      ║
║                                                                  ║
║  Incorrect examples — NEVER render these:                        ║
║    ✗ Small Room 5 10'-0" × 7'-0" (est.)                         ║
║    ✗ Corridor 6'-0" × 3'-0" (est.)                              ║
║    ✗ Stairs 10'-0" × 8'-0" (est.)                               ║
║    ✗ Bar Area 30'-0" × 25'-0"                                  ║
║    ✗ Total Width 50'                                            ║
║                                                                  ║
║  If a text cluster contains words + dimensions, delete the words ║
║  and keep only the numeric dimension.                            ║
╚══════════════════════════════════════════════════════════════════╝

INTERNAL COVERAGE — LOGIC ONLY, DO NOT RENDER THESE WORDS:
            """
            + area_coverage_block
            + "\n\n"
            + "INTERNAL MISSING-SIZE ESTIMATION HINTS — LOGIC ONLY, DO NOT RENDER THESE WORDS:\n"
            + missing_block
            + "\n\n"
            + """
MICRO-AREA DIMENSION COVERAGE — ABSOLUTE RULE:
• EVERY visually separated enclosed or usable region must receive one numeric L×W size callout.
• Do not skip small areas, tiny rooms, narrow corridors, stair pockets, service spaces,
  edge rooms, irregular niches, entries, porches, balconies, or partial-width spaces.
• If the area is too small for centered text, use smaller text or a short leader line.
• Every enclosed/usable area must have exactly one readable numeric L×W tag.
• Existing numeric dimensions must be copied exactly.
• Missing dimensions must be estimated and marked with (est.).
• Do not render area names, room names, or function labels — numeric dimensions only.

DIMENSION COUNT SELF-CHECK:
• Before output, count all visually separated enclosed/usable regions in IMAGE 1.
• Then count all interior L×W dimension tags in the final output.
• The count of interior L×W dimension tags must match the count of usable/enclosed regions.
• If even one small area has no numeric L×W tag, the render is incomplete and must be regenerated.

MEASUREMENT COVERAGE ALGORITHM:
1) Scan IMAGE 1 for numeric dimensions only.
2) Strip every non-numeric word from every text cluster.
3) Copy existing numeric dimensions exactly.
4) Estimate missing L×W values and mark only with (est.).
5) Place one numeric L×W tag inside each enclosed/usable area.
6) Outer boundary dimension lines must show numbers only, no TOTAL/OVERALL/WIDTH/DEPTH words.
7) Before final output, run a visible-text audit:
   if any visible text contains alphabetic words other than allowed unit symbols or (est.), remove it.

FINAL VISIBLE TEXT FORMAT:
• Interior areas: numeric L×W only.
• Outer dimensions: numeric value only.
• Wall height / window / door callouts: numeric value only if needed.
• No labels, no names, no titles, no functional words.

THREE-TIER DIMENSION SYSTEM — ALL THREE TIERS ARE MANDATORY

TIER 1 — NUMERIC L×W ONLY:
  • Place one compact numeric L×W dimension tag centered on each enclosed/usable floor region.
  • Existing source dimension: copy exactly, without (est.).
  • Missing source dimension: estimate and append (est.).
"""
            + "  • Format — ONE line or two lines in a small WHITE-FILLED RECTANGLE with BLACK BORDER:\n"
            + "        ┌────────────────────┐\n"
            + "        │   3.50 × 3.00 m    │\n"
            + "        └────────────────────┘\n"
            + "        ┌────────────────────┐\n"
            + "        │  5'-6\" × 3'-0\"   │\n"
            + "        │       (est.)       │\n"
            + "        └────────────────────┘\n"
            + "  • The tag MUST contain actual numbers and units.\n"
            + "  • The tag MUST NOT contain any room name, area name, function word, or label word.\n"
            + "  • Dimension every enclosed/usable floor region — no separated region is skipped.\n"
            + "  • Font: clean thin BLACK architectural sans-serif. NOT bold.\n\n"
            + "TIER 2 — BUILDING FOOTPRINT DIMENSIONS (NUMBERS ONLY):\n"
            + "  • Thin black dimension lines with tick endpoints OUTSIDE the footprint,\n"
            + "    offset 15–20px beyond the outermost wall.\n"
            + "  • Numeric value only on TOP and BOTTOM edges.\n"
            + "    Numeric value only on LEFT and RIGHT edges.\n"
            + "  • EACH LINE MUST HAVE A NUMERIC VALUE — not just a tick mark.\n"
            + "    Example: '12.50 m' or '41ft-0in' written along the dimension line.\n"
            + "  • Optional wall-thickness note must be numbers only: '" + wall_ext + " / " + wall_int + "'\n"
            + "  • All dimension lines must be fully within the canvas — never clipped.\n\n"
            + "TIER 3 — COMPONENT CALLOUTS (one of each, minimal):\n"
            + "  • Wall height callout on ONE exterior face: '" + wall_h + "' with arrow.\n"
            + "  • ONE door width callout: '" + door_w + "' with leader line.\n"
            + "  • ONE window width callout: '" + win_w + "' with leader line.\n"
            + "  • Staircase: numeric rise + tread count only if present.\n\n"
            + "DIMENSION SELF-CHECK — verify before output:\n"
            + "  □ Every enclosed/usable region has a numeric L×W tag?\n"
            + "  □ Areas that already had dimensions were copied exactly?\n"
            + "  □ Areas that lacked dimensions received estimated numbers with (est.)?\n"
            + "  □ No separated floor region is skipped?\n"
            + "  □ Zero room/function/area/label words are visible anywhere?\n"
            + "  □ Every outer dimension tick mark has a NUMBER next to it?\n"
            + "  □ No blank tick marks anywhere?\n"
        )
        return mandate
    # ╚═══ END DEAD: _build_measurement_mandate() — 276 lines ══════════════════╝

    # ╔═══ DEAD ════════════════════════════════════════════════════════════╗
    # ║ _build_initial_user_instruction_block()
    # ║ source: backend/app/ai/rendering.py  lines 2886-2971
    # ║ Reason: only called by apply_universal_style (dead).
    # ╚═══════════════════════════════════════════════════════════════════╝
    def _build_initial_user_instruction_block(self, prompt: Optional[str] = None) -> str:
        """
        Converts the user's initial generation prompt into a controlled Stage 2 directive.
        This lets user instructions pass through at initial generation time while protecting
        unrelated geometry, colours, labels, camera, and previously-good styling.
        """
        raw = (prompt or "").strip()

        default_floor = (
            "Default floor: light warm-grey polished concrete / microcement; "
            "subtle cloudy low-contrast material variation; matte/satin finish; "
            "no tile seams, no wood pattern, no marble veins, no carpet, no glossy reflection, "
            "no heavy/noisy shadows."
        )
        default_walls = (
            "Default walls: clean matte off-white / neutral architectural white; "
            "smooth plain surfaces; thick crisp black SketchUp-style outlines on wall tops, "
            "corners, openings, partitions, window/door frames, floor/wall junctions, and all boundaries; "
            "no wallpaper, brick, marble, decorative texture, random tint, or colour drift."
        )

        if not raw:
            return f"""
        No extra user instruction was provided for this initial render.
        Apply the approved default wall/floor theme:
        • {default_floor}
        • {default_walls}
        • Keep furniture policy from the floor plan analysis only.
        • Do not invent extra objects, labels, colours, or materials.
"""

        lowered = raw.lower()
        floor_terms = (
            "floor", "flooring", "tiles", "tile", "wood", "wooden", "marble",
            "concrete", "cement", "microcement", "carpet", "rug", "ground"
        )
        wall_terms = (
            "wall", "walls", "paint", "wallpaper", "brick", "plaster", "panel",
            "cladding", "partition", "colour", "color"
        )
        object_terms = (
            "furniture", "bed", "sofa", "chair", "table", "desk", "wardrobe",
            "cabinet", "counter", "toilet", "sink", "bathtub", "shower", "seat",
            "stool", "plant", "lamp", "decor", "fixture", "add"
        )

        mentions_floor = any(t in lowered for t in floor_terms)
        mentions_walls = any(t in lowered for t in wall_terms)
        mentions_objects = any(t in lowered for t in object_terms)

        floor_rule = (
            "User explicitly mentioned floor/flooring/material; follow the user's floor instruction exactly, "
            "but keep it clean, sharp, non-noisy, and SketchUp-style. Do not change walls unless requested."
            if mentions_floor else
            f"User did not give a floor instruction; apply this default floor exactly: {default_floor}"
        )
        wall_rule = (
            "User explicitly mentioned walls/paint/material; follow the user's wall instruction exactly, "
            "but keep wall boundaries, caps, and outlines crisp. Do not change floor unless requested."
            if mentions_walls else
            f"User did not give a wall instruction; apply this default wall style exactly: {default_walls}"
        )
        object_rule = (
            "User instruction may authorize adding/changing ONLY the explicitly requested furniture/fixtures/objects. "
            "Do not add any extra furniture based on room names or space type."
            if mentions_objects else
            "No explicit object/furniture addition was requested beyond source-plan symbols; keep normal furniture policy."
        )

        return f"""
        INITIAL USER PROMPT TEXT — pass this meaning to the model:
        "{raw}"

        APPLY-INSTRUCTION RULES:
        • Apply the user instruction only where it is explicit and relevant.
        • {floor_rule}
        • {wall_rule}
        • {object_rule}
        • Edit isolation: do NOT randomly change wall colours, toilet/bathroom colours,
          floor material, window style, labels, numeric dimensions, camera angle, lighting,
          room layout, wall positions, or unrelated elements.
        • If the user asks to add furniture, add only that requested furniture and preserve
          all default walls/floor/windows unless the user explicitly changes them.
        • If any user request conflicts with geometry lock, geometry lock wins.
        • If the user instruction is vague or unrelated, keep the approved default theme.
"""
    # ╚═══ END DEAD: _build_initial_user_instruction_block() ═══════════════════╝

