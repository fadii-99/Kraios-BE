"""Style-reference ordering helpers for the guided Gemini Step 2 pipeline."""
from __future__ import annotations

import mimetypes
from pathlib import Path

from app.ai.config import ai_settings


def guess_mime(path: str | Path) -> str:
    mime, _ = mimetypes.guess_type(str(path))
    return mime or "image/png"


def bundled_sketchup_reference(mode: str) -> tuple[bytes, str] | None:
    """Return the bundled SketchUp style reference, when configured and present."""
    if mode != "sketchup":
        return None
    ref_path = ai_settings.SKETCHUP_STYLE_REF
    if ref_path.is_file():
        return ref_path.read_bytes(), "image/png"
    return None


def asset_style_references(paths: list[str]) -> list[tuple[bytes, str]]:
    """Read user-provided style references in caller-provided order."""
    refs: list[tuple[bytes, str]] = []
    for path in paths:
        if not path:
            continue
        file_path = Path(path)
        if not file_path.is_file():
            continue
        refs.append((file_path.read_bytes(), guess_mime(file_path)))
    return refs
