"""Debug-only Pillow FloorPlan snapshot utility.

Normal Step 2 generation must use a frontend three.js WebGL snapshot uploaded as a
RENDER_SNAPSHOT asset. This module is intentionally not imported by the official
Step 2 render path.
"""
from __future__ import annotations

import uuid
from pathlib import Path

from PIL import Image, ImageDraw

from app.ai.config import ai_settings
from app.ai.floorplan_schema import FloorPlan


def _bounds(plan: FloorPlan) -> tuple[float, float, float, float]:
    points: list[tuple[float, float]] = []
    points.extend(tuple(p) for p in plan.outline or [])
    for wall in plan.walls:
        points.append(tuple(wall.start))
        points.append(tuple(wall.end))
    for room in plan.rooms:
        points.extend(tuple(p) for p in room.polygon)
    if not points:
        return 0, 0, 10, 10
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return min(xs), min(ys), max(xs), max(ys)


def _project_point(
    x: float,
    y: float,
    z: float,
    *,
    min_x: float,
    min_y: float,
    scale: float,
    offset_x: float,
    offset_y: float,
) -> tuple[float, float]:
    px = (x - min_x) * scale
    py = (y - min_y) * scale
    iso_x = (px - py) * 0.72 + offset_x
    iso_y = (px + py) * 0.38 - z * scale * 0.58 + offset_y
    return iso_x, iso_y


def _poly(points) -> list[tuple[int, int]]:
    return [(round(x), round(y)) for x, y in points]


def _draw_snapshot(plan: FloorPlan) -> Image.Image:
    """Draw the open-top massing shell and return the PIL image (no disk I/O)."""
    min_x, min_y, max_x, max_y = _bounds(plan)
    width_m = max(max_x - min_x, 1.0)
    height_m = max(max_y - min_y, 1.0)
    canvas_w = 1400
    canvas_h = 1000
    scale = min(52.0, max(22.0, min(canvas_w / (width_m + height_m + 6), canvas_h / (width_m + height_m + 8)) * 1.45))
    offset_x = canvas_w / 2
    offset_y = 190
    wall_h = plan.wall_height or 2.7

    img = Image.new("RGB", (canvas_w, canvas_h), "#0b0d12")
    draw = ImageDraw.Draw(img, "RGBA")

    grid_color = (45, 51, 59, 70)
    for i in range(-20, 45):
        a = _project_point(min_x + i, min_y - 10, 0, min_x=min_x, min_y=min_y, scale=scale, offset_x=offset_x, offset_y=offset_y)
        b = _project_point(min_x + i, max_y + 10, 0, min_x=min_x, min_y=min_y, scale=scale, offset_x=offset_x, offset_y=offset_y)
        draw.line(_poly([a, b]), fill=grid_color, width=1)
        c = _project_point(min_x - 10, min_y + i, 0, min_x=min_x, min_y=min_y, scale=scale, offset_x=offset_x, offset_y=offset_y)
        d = _project_point(max_x + 10, min_y + i, 0, min_x=min_x, min_y=min_y, scale=scale, offset_x=offset_x, offset_y=offset_y)
        draw.line(_poly([c, d]), fill=grid_color, width=1)

    floor_points = plan.outline if len(plan.outline) >= 3 else []
    if not floor_points and plan.rooms:
        floor_points = plan.rooms[0].polygon
    if floor_points:
        floor = [
            _project_point(x, y, 0, min_x=min_x, min_y=min_y, scale=scale, offset_x=offset_x, offset_y=offset_y)
            for x, y in floor_points
        ]
        draw.polygon(_poly(floor), fill=(58, 65, 80, 245), outline=(170, 185, 205, 255))

    for room in plan.rooms or []:
        if len(room.polygon) < 3:
            continue
        pts = [
            _project_point(x, y, 0.01, min_x=min_x, min_y=min_y, scale=scale, offset_x=offset_x, offset_y=offset_y)
            for x, y in room.polygon
        ]
        draw.line(_poly(pts + [pts[0]]), fill=(110, 128, 150, 120), width=2)

    for wall in plan.walls:
        x1, y1 = wall.start
        x2, y2 = wall.end
        b1 = _project_point(x1, y1, 0, min_x=min_x, min_y=min_y, scale=scale, offset_x=offset_x, offset_y=offset_y)
        b2 = _project_point(x2, y2, 0, min_x=min_x, min_y=min_y, scale=scale, offset_x=offset_x, offset_y=offset_y)
        t2 = _project_point(x2, y2, wall_h, min_x=min_x, min_y=min_y, scale=scale, offset_x=offset_x, offset_y=offset_y)
        t1 = _project_point(x1, y1, wall_h, min_x=min_x, min_y=min_y, scale=scale, offset_x=offset_x, offset_y=offset_y)
        draw.polygon(_poly([b1, b2, t2, t1]), fill=(207, 214, 224, 230), outline=(245, 248, 252, 255))
        draw.line(_poly([t1, t2]), fill=(255, 255, 255, 255), width=max(2, round((wall.thickness or 0.15) * scale)))

    return img


def render_floorplan_snapshot_bytes(plan: FloorPlan) -> bytes:
    """Render the massing-shell snapshot straight to PNG bytes (no disk I/O).

    Used by the fidelity auditor to eyeball the extracted geometry against the
    original 2D plan without persisting a throwaway file.
    """
    import io

    buf = io.BytesIO()
    _draw_snapshot(plan).save(buf, format="PNG")
    return buf.getvalue()


def render_floorplan_snapshot(plan: FloorPlan, project_id: str) -> tuple[str, str]:
    """Render a clean open-top shell snapshot from validated FloorPlan JSON."""
    img = _draw_snapshot(plan)
    output_dir = Path(ai_settings.OUTPUT_DIR) / "snapshots"
    output_dir.mkdir(parents=True, exist_ok=True)
    file_path = output_dir / f"floorplan_snapshot_{project_id}_{uuid.uuid4()}.png"
    img.save(file_path, format="PNG")
    rel_path = file_path.relative_to(Path(ai_settings.OUTPUT_DIR))
    return str(file_path), f"/outputs/{rel_path.as_posix()}"
